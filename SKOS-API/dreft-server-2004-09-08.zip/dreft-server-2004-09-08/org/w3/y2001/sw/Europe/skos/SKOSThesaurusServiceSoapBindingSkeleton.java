/**
 * SKOSThesaurusServiceSoapBindingSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package org.w3.y2001.sw.Europe.skos;

public class SKOSThesaurusServiceSoapBindingSkeleton implements org.w3.y2001.sw.Europe.skos.SKOSThesaurus, org.apache.axis.wsdl.Skeleton {
    private org.w3.y2001.sw.Europe.skos.SKOSThesaurus impl;
    private static java.util.Map _myOperations = new java.util.Hashtable();
    private static java.util.Collection _myOperationsList = new java.util.ArrayList();

    /**
    * Returns List of OperationDesc objects with this name
    */
    public static java.util.List getOperationDescByName(java.lang.String methodName) {
        return (java.util.List)_myOperations.get(methodName);
    }

    /**
    * Returns Collection of OperationDescs
    */
    public static java.util.Collection getOperationDescs() {
        return _myOperationsList;
    }

    static {
        org.apache.axis.description.OperationDesc _oper;
        org.apache.axis.description.FaultDesc _fault;
        org.apache.axis.description.ParameterDesc [] _params;
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "URI"), org.w3.y2001.sw.Europe.skos.URI.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getConcept", _params, new javax.xml.namespace.QName("", "getConceptReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Concept"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getConcept"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getConcept") == null) {
            _myOperations.put("getConcept", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getConcept")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getConceptsMatchingKeyword", _params, new javax.xml.namespace.QName("", "getConceptsMatchingKeywordReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_Concept"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getConceptsMatchingKeyword"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getConceptsMatchingKeyword") == null) {
            _myOperations.put("getConceptsMatchingKeyword", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getConceptsMatchingKeyword")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getConceptsMatchingRegex", _params, new javax.xml.namespace.QName("", "getConceptsMatchingRegexReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_Concept"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getConceptsMatchingRegex"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getConceptsMatchingRegex") == null) {
            _myOperations.put("getConceptsMatchingRegex", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getConceptsMatchingRegex")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
        };
        _oper = new org.apache.axis.description.OperationDesc("getSupportedSemanticRelations", _params, new javax.xml.namespace.QName("", "getSupportedSemanticRelationsReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_Relation"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getSupportedSemanticRelations"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getSupportedSemanticRelations") == null) {
            _myOperations.put("getSupportedSemanticRelations", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getSupportedSemanticRelations")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Concept"), org.w3.y2001.sw.Europe.skos.Concept.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Relation"), org.w3.y2001.sw.Europe.skos.Relation.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getConceptRelatives", _params, new javax.xml.namespace.QName("", "getConceptRelativesReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_Concept"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getConceptRelatives"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getConceptRelatives") == null) {
            _myOperations.put("getConceptRelatives", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getConceptRelatives")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Concept"), org.w3.y2001.sw.Europe.skos.Concept.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getAllConceptRelatives", _params, new javax.xml.namespace.QName("", "getAllConceptRelativesReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_Concept"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getAllConceptRelatives"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getAllConceptRelatives") == null) {
            _myOperations.put("getAllConceptRelatives", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getAllConceptRelatives")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "URI"), org.w3.y2001.sw.Europe.skos.URI.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getTopmostConcepts", _params, new javax.xml.namespace.QName("", "getTopmostConceptsReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_Concept"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getTopmostConcepts"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getTopmostConcepts") == null) {
            _myOperations.put("getTopmostConcepts", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getTopmostConcepts")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Concept"), org.w3.y2001.sw.Europe.skos.Concept.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "URI"), org.w3.y2001.sw.Europe.skos.URI.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getTopConcepts", _params, new javax.xml.namespace.QName("", "getTopConceptsReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_Concept"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getTopConcepts"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getTopConcepts") == null) {
            _myOperations.put("getTopConcepts", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getTopConcepts")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "URI"), org.w3.y2001.sw.Europe.skos.URI.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getConceptByPreferredLabel", _params, new javax.xml.namespace.QName("", "getConceptByPreferredLabelReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Concept"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getConceptByPreferredLabel"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getConceptByPreferredLabel") == null) {
            _myOperations.put("getConceptByPreferredLabel", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getConceptByPreferredLabel")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "URI"), org.w3.y2001.sw.Europe.skos.URI.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getConceptByExternalID", _params, new javax.xml.namespace.QName("", "getConceptByExternalIDReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Concept"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getConceptByExternalID"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getConceptByExternalID") == null) {
            _myOperations.put("getConceptByExternalID", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getConceptByExternalID")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "URI"), org.w3.y2001.sw.Europe.skos.URI.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getConceptsMatchingKeywordByThesaurus", _params, new javax.xml.namespace.QName("", "getConceptsMatchingKeywordByThesaurusReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_Concept"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getConceptsMatchingKeywordByThesaurus"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getConceptsMatchingKeywordByThesaurus") == null) {
            _myOperations.put("getConceptsMatchingKeywordByThesaurus", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getConceptsMatchingKeywordByThesaurus")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "URI"), org.w3.y2001.sw.Europe.skos.URI.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getConceptsMatchingRegexByThesaurus", _params, new javax.xml.namespace.QName("", "getConceptsMatchingRegexByThesaurusReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_Concept"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getConceptsMatchingRegexByThesaurus"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getConceptsMatchingRegexByThesaurus") == null) {
            _myOperations.put("getConceptsMatchingRegexByThesaurus", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getConceptsMatchingRegexByThesaurus")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "URI"), org.w3.y2001.sw.Europe.skos.URI.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getSupportedSemanticRelationsByThesaurus", _params, new javax.xml.namespace.QName("", "getSupportedSemanticRelationsByThesaurusReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_Relation"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getSupportedSemanticRelationsByThesaurus"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getSupportedSemanticRelationsByThesaurus") == null) {
            _myOperations.put("getSupportedSemanticRelationsByThesaurus", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getSupportedSemanticRelationsByThesaurus")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Concept"), org.w3.y2001.sw.Europe.skos.Concept.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Relation"), org.w3.y2001.sw.Europe.skos.Relation.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "URI"), org.w3.y2001.sw.Europe.skos.URI.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getConceptRelativesByThesaurus", _params, new javax.xml.namespace.QName("", "getConceptRelativesByThesaurusReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_Concept"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getConceptRelativesByThesaurus"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getConceptRelativesByThesaurus") == null) {
            _myOperations.put("getConceptRelativesByThesaurus", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getConceptRelativesByThesaurus")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Concept"), org.w3.y2001.sw.Europe.skos.Concept.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "URI"), org.w3.y2001.sw.Europe.skos.URI.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getAllConceptRelativesByThesaurus", _params, new javax.xml.namespace.QName("", "getAllConceptRelativesByThesaurusReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_Concept"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getAllConceptRelativesByThesaurus"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getAllConceptRelativesByThesaurus") == null) {
            _myOperations.put("getAllConceptRelativesByThesaurus", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getAllConceptRelativesByThesaurus")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Concept"), org.w3.y2001.sw.Europe.skos.Concept.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Relation"), org.w3.y2001.sw.Europe.skos.Relation.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "URI"), org.w3.y2001.sw.Europe.skos.URI.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getConceptRelativesByPath", _params, new javax.xml.namespace.QName("", "getConceptRelativesByPathReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_ConceptRelatives"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getConceptRelativesByPath"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getConceptRelativesByPath") == null) {
            _myOperations.put("getConceptRelativesByPath", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getConceptRelativesByPath")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Concept"), org.w3.y2001.sw.Europe.skos.Concept.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Relation"), org.w3.y2001.sw.Europe.skos.Relation.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getAllConceptsByPath", _params, new javax.xml.namespace.QName("", "getAllConceptsByPathReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_ConceptRelatives"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getAllConceptsByPath"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getAllConceptsByPath") == null) {
            _myOperations.put("getAllConceptsByPath", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getAllConceptsByPath")).add(_oper);
    }

    public SKOSThesaurusServiceSoapBindingSkeleton() {
        this.impl = new org.w3.y2001.sw.Europe.skos.SKOSThesaurusServiceSoapBindingImpl();
    }

    public SKOSThesaurusServiceSoapBindingSkeleton(org.w3.y2001.sw.Europe.skos.SKOSThesaurus impl) {
        this.impl = impl;
    }
    public org.w3.y2001.sw.Europe.skos.Concept getConcept(org.w3.y2001.sw.Europe.skos.URI in0) throws java.rmi.RemoteException
    {
        org.w3.y2001.sw.Europe.skos.Concept ret = impl.getConcept(in0);
        return ret;
    }

    public org.w3.y2001.sw.Europe.skos.Concept[] getConceptsMatchingKeyword(java.lang.String in0) throws java.rmi.RemoteException
    {
        org.w3.y2001.sw.Europe.skos.Concept[] ret = impl.getConceptsMatchingKeyword(in0);
        return ret;
    }

    public org.w3.y2001.sw.Europe.skos.Concept[] getConceptsMatchingRegex(java.lang.String in0) throws java.rmi.RemoteException
    {
        org.w3.y2001.sw.Europe.skos.Concept[] ret = impl.getConceptsMatchingRegex(in0);
        return ret;
    }

    public org.w3.y2001.sw.Europe.skos.Relation[] getSupportedSemanticRelations() throws java.rmi.RemoteException
    {
        org.w3.y2001.sw.Europe.skos.Relation[] ret = impl.getSupportedSemanticRelations();
        return ret;
    }

    public org.w3.y2001.sw.Europe.skos.Concept[] getConceptRelatives(org.w3.y2001.sw.Europe.skos.Concept in0, org.w3.y2001.sw.Europe.skos.Relation in1) throws java.rmi.RemoteException
    {
        org.w3.y2001.sw.Europe.skos.Concept[] ret = impl.getConceptRelatives(in0, in1);
        return ret;
    }

    public org.w3.y2001.sw.Europe.skos.Concept[] getAllConceptRelatives(org.w3.y2001.sw.Europe.skos.Concept in0) throws java.rmi.RemoteException
    {
        org.w3.y2001.sw.Europe.skos.Concept[] ret = impl.getAllConceptRelatives(in0);
        return ret;
    }

    public org.w3.y2001.sw.Europe.skos.Concept[] getTopmostConcepts(org.w3.y2001.sw.Europe.skos.URI in0) throws java.rmi.RemoteException
    {
        org.w3.y2001.sw.Europe.skos.Concept[] ret = impl.getTopmostConcepts(in0);
        return ret;
    }

    public org.w3.y2001.sw.Europe.skos.Concept[] getTopConcepts(org.w3.y2001.sw.Europe.skos.Concept in0, org.w3.y2001.sw.Europe.skos.URI in1) throws java.rmi.RemoteException
    {
        org.w3.y2001.sw.Europe.skos.Concept[] ret = impl.getTopConcepts(in0, in1);
        return ret;
    }

    public org.w3.y2001.sw.Europe.skos.Concept getConceptByPreferredLabel(java.lang.String in0, org.w3.y2001.sw.Europe.skos.URI in1) throws java.rmi.RemoteException
    {
        org.w3.y2001.sw.Europe.skos.Concept ret = impl.getConceptByPreferredLabel(in0, in1);
        return ret;
    }

    public org.w3.y2001.sw.Europe.skos.Concept getConceptByExternalID(java.lang.String in0, org.w3.y2001.sw.Europe.skos.URI in1) throws java.rmi.RemoteException
    {
        org.w3.y2001.sw.Europe.skos.Concept ret = impl.getConceptByExternalID(in0, in1);
        return ret;
    }

    public org.w3.y2001.sw.Europe.skos.Concept[] getConceptsMatchingKeywordByThesaurus(java.lang.String in0, org.w3.y2001.sw.Europe.skos.URI in1) throws java.rmi.RemoteException
    {
        org.w3.y2001.sw.Europe.skos.Concept[] ret = impl.getConceptsMatchingKeywordByThesaurus(in0, in1);
        return ret;
    }

    public org.w3.y2001.sw.Europe.skos.Concept[] getConceptsMatchingRegexByThesaurus(java.lang.String in0, org.w3.y2001.sw.Europe.skos.URI in1) throws java.rmi.RemoteException
    {
        org.w3.y2001.sw.Europe.skos.Concept[] ret = impl.getConceptsMatchingRegexByThesaurus(in0, in1);
        return ret;
    }

    public org.w3.y2001.sw.Europe.skos.Relation[] getSupportedSemanticRelationsByThesaurus(org.w3.y2001.sw.Europe.skos.URI in0) throws java.rmi.RemoteException
    {
        org.w3.y2001.sw.Europe.skos.Relation[] ret = impl.getSupportedSemanticRelationsByThesaurus(in0);
        return ret;
    }

    public org.w3.y2001.sw.Europe.skos.Concept[] getConceptRelativesByThesaurus(org.w3.y2001.sw.Europe.skos.Concept in0, org.w3.y2001.sw.Europe.skos.Relation in1, org.w3.y2001.sw.Europe.skos.URI in2) throws java.rmi.RemoteException
    {
        org.w3.y2001.sw.Europe.skos.Concept[] ret = impl.getConceptRelativesByThesaurus(in0, in1, in2);
        return ret;
    }

    public org.w3.y2001.sw.Europe.skos.Concept[] getAllConceptRelativesByThesaurus(org.w3.y2001.sw.Europe.skos.Concept in0, org.w3.y2001.sw.Europe.skos.URI in1) throws java.rmi.RemoteException
    {
        org.w3.y2001.sw.Europe.skos.Concept[] ret = impl.getAllConceptRelativesByThesaurus(in0, in1);
        return ret;
    }

    public org.w3.y2001.sw.Europe.skos.ConceptRelatives[] getConceptRelativesByPath(org.w3.y2001.sw.Europe.skos.Concept in0, org.w3.y2001.sw.Europe.skos.Relation in1, org.w3.y2001.sw.Europe.skos.URI in2, int in3) throws java.rmi.RemoteException
    {
        org.w3.y2001.sw.Europe.skos.ConceptRelatives[] ret = impl.getConceptRelativesByPath(in0, in1, in2, in3);
        return ret;
    }

    public org.w3.y2001.sw.Europe.skos.ConceptRelatives[] getAllConceptsByPath(org.w3.y2001.sw.Europe.skos.Concept in0, org.w3.y2001.sw.Europe.skos.Relation in1, int in2) throws java.rmi.RemoteException
    {
        org.w3.y2001.sw.Europe.skos.ConceptRelatives[] ret = impl.getAllConceptsByPath(in0, in1, in2);
        return ret;
    }

}
