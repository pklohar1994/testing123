package org.w3.y2001.sw.Europe.skos.query;


import org.w3.y2001.sw.Europe.skos.Relation;
import org.w3.y2001.sw.Europe.skos.URI;

public abstract class AbstractQuery {

/*	TODO - delete these thinks when sorted em out. [incoming query mapping to RDF query lang]
	variables: URI, Ext_id, Thesaurus_id, sem_relation, query_string, 
	(any of these can be null - they'll be given values
	depending on which constructor is used on this object, 
	and that'll aid the query parser to 
	work out what the query is after. 
	Alternatively there won't be different constructor invocations, 
	instead just a props object sent to the constructor method, 
	allowing it to be examined on construction and appropriate variables - 
	UTI, Ext_id etc initialised with values if found in the props object. 
	I think this latter way might be more efficient but perhaps less easy to 
	do error handling on?).
*/
	protected URI concept_uri;	
	protected String Ext_id;		
	protected URI thesaurus_id;
	protected Relation sem_relation;
	protected String query_string;


	public AbstractQuery() {
		
	}
	
	public void setQuery(String query_str) {
		query_string = query_str;
	}
	
	public String getQuery() { 
		return query_string;
	}
	
	public void parseQuery(String substring_to_match) {
	}

	public void parseQuery(String substring_to_match, URI thesaurus_uri) {
	}

	public void parseQuery(URI uri_str) {
	}	

	public void parseGetTopConceptsQuery(URI uri_str) {
	}	

	public void parseQuery(String the_concepts_property_value, URI thes, String property_name) {
	}		

	public void parseQuery(URI uri_str, Relation reln) {
	}		
				
	public void parseQuery(URI uri_str, Relation reln, URI thes) {
	}		
	
	public void parseQuery(URI uri_str, URI thes) {
	}
	public void parseQuery(URI uri_str, String relations) {
	}
	public void parseQuery(URI ur_uri, String relations, URI thes) {
	}
	public void parseExactQuery(URI uri_, String preferred_label) {
	}
			
}
	