package org.w3.y2001.sw.Europe.skos.repository;

import org.openrdf.sesame.config.RepositoryConfig;
import org.openrdf.sesame.config.SailConfig;

import org.openrdf.sesame.repository.local.LocalService;
import org.openrdf.sesame.Sesame;
import org.openrdf.sesame.repository.SesameRepository;
import org.openrdf.sesame.config.ConfigurationException;
import org.openrdf.sesame.config.UnknownRepositoryException;

import java.io.IOException;
import java.io.FileNotFoundException;

import org.openrdf.sesame.admin.AdminMsgCollector;
import org.openrdf.sesame.config.AccessDeniedException;
import java.util.List;
import java.util.Iterator;
import java.util.Properties;
import org.openrdf.sesame.admin.AdminMsg;
import org.openrdf.sesame.query.QueryResultsTable;
import org.openrdf.model.Value;
import org.openrdf.sesame.constants.QueryLanguage;

import org.apache.log4j.Logger;

import org.w3.y2001.sw.Europe.skos.Concept;
import org.w3.y2001.sw.Europe.skos.URI;
import org.w3.y2001.sw.Europe.skos.query.AbstractQuery;
import java.util.ArrayList;

import javax.servlet.http.HttpServlet;
import javax.servlet.ServletContext;
import org.apache.axis.MessageContext;
import org.apache.axis.transport.http.HTTPConstants;
import java.io.FileInputStream;

/**
 *
 * @author Nikki Rogers
  */
public class SesameRepo extends AbstractRepo {

	/**
	 * This class is an extension of the AbstractRepo class. 
	 * We would expect it to be instantiated by the DemoService class and consequently used to handle the
	 * issuing of queries against a Sesame repository, the retrieval of results from Sesame, and the parsing
	 * of those results into Concept objects.
	 * Key method implementations are:
	 * doSearch_for_concept and doSearch_for_concepts. These are generic methods that,
	 * given a query object, will extract its query string (already parsed into an RDF Query format at an
	 * earlier stage)
	 * and submit it to a Sesame repository. (The Sesame repository is configured by the configure_repo 
	 * method in this class). We have coded this class so that Sesame will return its results in a results
	 * table format (as opposed to say N3 or RDF/XML). We then iterate through the rows and columns
	 * of this results table (to understand this logically: each row has subject-pred-obj format corresponding 
	 * to ConceptUri-property-propertyValue). And as properties are discovered to match preferred labels,
	 * external id's, scope notes etc, so a Concept bean has its fields "filled up" with the appropriate
	 * property values.  Finally, these key methods returning a singleton Concept object or array of Concepts
	 * as expected. 
	 * @return 
	 * @exception 
	 * 
	  **/
	protected String repo_id;
	
	ArrayList non_pref_term_list;
	ArrayList concept_resultset;
	Concept[] concept_results;
	
	// Relational database Configuration parameters
	String JDBCdriver;
	String JDBCConnectionURL;
	String User;
	String Password;	
	// Sesame Configuration parameters
	String RepoID;	
	String RepoName;
	String RuleFile;
	String SyncSail;
	String PermSail;
	private RepositoryConfig repo_config;
		
	private String skosNamespaceUri = "http://www.w3.org/2004/02/skos/core#";
	
	static Logger logger = Logger.getLogger(SesameRepo.class.getName());
	
	public SesameRepo(){
		logger.debug(this + "Constructing a SesameRepo");			
	}
	
	/*
	public SesameRepo(String repo_id)
		 {
	
					  super(repo_id);
					  this.repo_id = repo_id;
					  logger.debug(this + "Constructing a SesameRepo");				
		
		 }
	 */
	
	
        
	public Concept doSearch_for_concept(AbstractQuery query) {
	 
	 		Concept empty_conc = null;
		 	try {	
	 		Concept[] single_concept_array = doSearch_for_concepts(query);
	 		// return first member of array
			if (single_concept_array.length == 0) {
					return empty_conc;
			} else {
			return single_concept_array[0];
			}
	 		} catch ( java.lang.IndexOutOfBoundsException ioobe)
		{
			
			logger.error(this +"Array problem when returning single concept " + ioobe);			

		}
		catch ( java.lang.Exception e)
			{
			
				logger.error(this +"Problem with returning a single concept " +e);
			}
	 		return null;
	
	}

    private void logAdminMessages(AdminMsgCollector admin_info) {
		List msgs = admin_info.getMessages();
	
		Iterator i = msgs.iterator();
		while (i.hasNext()) {
			AdminMsg msg = (AdminMsg)i.next();
			//System.out.println(msg.getMessage());
			logger.error(this + msg.getMessage());	
    	}
    }
     	
	public Concept[] doSearch_for_concepts(AbstractQuery query) {
		
		
		// Next, we need to actually create this repository.
		// We do this by creating a LocalService, handing it the configuration, and then retrieving 
		// the repository from the service.
		LocalService service = Sesame.getService();
		
		AdminMsgCollector admin_info = new AdminMsgCollector();		
	
	try {
		
		service.addRepository(repo_config);

		SesameRepository myRepository = service.getRepository(RepoID);
		
		// A query to test skos:related. Without inferencing, this query brings back just 1 result:
		// http:/example.com/Concept/0003
		// I need it to bring back concept 0004 as well when transivity working - currently not working even though rule file read in
		// String query = "select Y from  {X : core:Concept } core:related {Y} where  X like \"http:/example.com/Concept/0002\" using namespace core = http://www.w3.org/2004/02/skos/core#";
		
		//String query = "select * from  {X} core:broader {Y} where  Y like \"http:/example.com/Concept/0002\" using namespace  core = http://www.w3.org/2004/02/skos/core#";
		//String query = "select * from  {X} @P {Y}";
		//String query = "select X, @PROPERTY, VALUE from  {X : core:Concept } core:broader {Y}, {X} @PROPERTY {VALUE} where  Y like \"http:/example.com/Concept/0002\" using namespace core = http://www.w3.org/2004/02/skos/core#";
		String query_str = query.getQuery();
		
		//System.out.println("Now gonna issue a query against the repository");
		//System.out.println("Query is:  " + query_str);
	
		// Ascertain what type of internal query object we have, (RQL, SERQL RDQL, whatever)
		// so we are able to instruct sesame appropriately.
		
		// TODO: This looks particularly dubious - using substrings of the class name to switch on.
		String query_type = query.getClass().getName();
		QueryLanguage query_format = null;
		
		if (query_type.indexOf("SERQL") != -1) 
		{
			//System.out.println("Detected SERQL query ");
			logger.debug(this + "Detected a SERQL query '" + query_str + "'");	
			query_format = QueryLanguage.SERQL;
			
		}
		else if  (query_type.indexOf("RQL") != -1)  {
			//System.out.println("Detected RQL query ");
			logger.debug(this + "Detected RQL query '" + query_str + "'");	
			query_format = QueryLanguage.RQL;
		}
		else {
			// default to SERQL
			//System.out.println("Defaulting to SERQL query ");
			logger.debug(this + "Defaulting to SERQL query '" + query_str + "'");	
			query_format = QueryLanguage.SERQL;
		}
		
		QueryResultsTable resultsTable = myRepository.performTableQuery(query_format, query_str);

		/*
		// *******************debugging only ******************
		System.out.println("Got a results table with " + resultsTable.getRowCount() + " rows in it.");
		for (int row = 0; row < resultsTable.getRowCount(); row++) {
				for (int column = 0; column < resultsTable.getColumnCount(); column++) {
					Value value = resultsTable.getValue(row, column);

					System.out.print(value.toString());
					System.out.print(" ");
					
				}
				System.out.println();
			}
		//*******************debugging only ******************
	    */
			
			
		// instantiate an arraylist object to hold as many concept objects as the result set brings back
		concept_resultset  = new ArrayList();
		
		//		get uri of first concept in the results table
		Value curr_concept = resultsTable.getValue(0,0);
		//System.out.println(curr_concept.toString());
		
		
		//		instantiate an arraylist object to hold non-preferred terms as and when they arise
		non_pref_term_list = new ArrayList();
		
		Concept concept_bean = new Concept();
		//System.out.println("Just constructed a new bean ready for filling XXXXXXXXXXXXx");
		logger.debug(this + "***** Constructed a concept bean ready for filling *****");	
		
		int row = 0;
		int col = 0;	
		for (int row_n = 0; row_n < (resultsTable.getRowCount() -1); row_n++) {
						
			do {
				curr_concept = resultsTable.getValue(row,col);
					
				if (curr_concept != null) {
					if(curr_concept instanceof org.openrdf.model.URI) {
						URI tmp_uri = new URI();
						tmp_uri.setUri(((org.openrdf.model.URI)curr_concept).getURI());
						concept_bean.setUri(tmp_uri);
						tmp_uri = null;
					}
					
					// TODO separate out the namespace & property name for each of prefLabel etc	
					// this can then be configured via intial parameters etc
					String curr_property = resultsTable.getValue(row,1).toString();			
					if (curr_property.equals(skosNamespaceUri+"prefLabel")) {
						// System.out.println("gotta pref label for the bean: " +resultsTable.getValue(row,2).toString());
						concept_bean.setPreferredLabel(resultsTable.getValue(row,2).toString());
					} else if (curr_property.equals(skosNamespaceUri+"definition")) {
					   // System.out.println("gotta definition for the bean: " +resultsTable.getValue(row,2).toString());
					   concept_bean.setDefinition(resultsTable.getValue(row,2).toString());
					} else if (curr_property.equals(skosNamespaceUri+"example")) {
					   // System.out.println("gotta example for the bean: " +resultsTable.getValue(row,2).toString());
					   concept_bean.setExample(resultsTable.getValue(row,2).toString());
					} else if (curr_property.equals(skosNamespaceUri+"scopeNote")) {
					   // System.out.println("gotta scopeNote for the bean: " +resultsTable.getValue(row,2).toString());
					   concept_bean.setScopeNote(resultsTable.getValue(row,2).toString());
					} else if (curr_property.toString().equals(skosNamespaceUri+"externalID")) {
						//	System.out.println("gotta external id for the bean: " +resultsTable.getValue(row,2).toString());
						concept_bean.setExternalID(resultsTable.getValue(row,2).toString());
					} else if (curr_property.toString().equals(skosNamespaceUri+"inScheme")) {
						URI tmp_uri = new URI();
						tmp_uri.setUri(resultsTable.getValue(row,2).toString());
						concept_bean.setInScheme(tmp_uri);
						tmp_uri = null;
					} else if (curr_property.equals(skosNamespaceUri+"altLabel")) {
						// System.out.println("gotta alt (non pref) for the bean: " +resultsTable.getValue(row,2).toString());
						add_to_nonprefLabel_array(resultsTable.getValue(row,2).toString());		
					} 				
				} // end if
					
				logger.debug(this + "***** Current concept being processed is known as  *****" + curr_concept);			
				//System.out.println("doing a bean, current concept is " + curr_concept);
				//System.out.println("Property is " + resultsTable.getValue(row,1));
				//System.out.println("Value is " + resultsTable.getValue(row,2));
				
			 } while ((row++ < (resultsTable.getRowCount()-1)) && resultsTable.getValue(row,col).equals(curr_concept));
			//  cast from array list to a string array because Axis software handles arrays most easily
		String[] str = (String []) non_pref_term_list.toArray(new String [non_pref_term_list.size()]);
		concept_bean.setNonPreferredLabels(str);
						  
		//System.out.println("left while loop now");
		// We've finished creating the bean for that particular concept so add the concept bean to the concept bean result set
		add_to_concept_array(concept_bean);
		// reset the non pref term array list
		non_pref_term_list = new ArrayList();
		logger.debug(this + "***** Finished constructing a Concept bean *****");	
		//System.out.println("Just constructed a new bean XXXXXXXXXXXXx");

		concept_bean = new Concept();
			
		} // end for loop
		
		
		
	}
	catch ( java.lang.IndexOutOfBoundsException ioobe)
	{
		logger.error(ioobe);	
	}
	catch (FileNotFoundException fnfe)
	{
		logAdminMessages(admin_info);
		//System.out.println(fnfe);
		logger.error(fnfe);	
	}
	catch (AccessDeniedException ade)
	{
		logAdminMessages(admin_info);
		//System.out.println(ade);
		logger.error(ade);	
	}
	catch (IOException ioe)
	{
		logAdminMessages(admin_info);
		//System.out.println("IO exception" + ioe);
		logger.error(this + "IO exception: " + ioe);	
	}
	catch (ConfigurationException cfe)
	{
		logAdminMessages(admin_info);
		//System.out.println(cfe);					
		logger.error(cfe);	
	}
	catch (UnknownRepositoryException ure) {
		logAdminMessages(admin_info);
		//System.out.println(ure);
		logger.error(ure);	
	}
	catch (Exception e)
	{
		logAdminMessages(admin_info);
  	    logger.error(e);	
	}
	
	// now lets get the concept results we've been storing & return them	
	return (Concept []) concept_resultset.toArray(new Concept [concept_resultset.size()]);

	}
	
	
	public void configure(RepositoryMode mode) {
		
		Properties repo_props= new Properties();
			
			if (mode == RepositoryMode.SERVLET) {
				//		Note: we could instead put values in web.xml (instead of a properties file) for extraction via servletcontext
				// Here we obtain the real as opposed to virtual path to the configuration properties files
			 	MessageContext mContext = MessageContext.getCurrentContext();
			 	HttpServlet serv = (HttpServlet) mContext.getProperty(HTTPConstants.MC_HTTP_SERVLET);
			 	ServletContext cx = serv.getServletContext();	
				String ses_props_file = null;
				// TODO - get this properties filename passed in
				if (cx.getRealPath("WEB-INF/configuration/sesame/rdf_database.properties") != null)
				{
					ses_props_file = cx.getRealPath("WEB-INF/configuration/sesame/rdf_database.properties");
				}
				else
				{
					logger.error("Unable to get the real path to the RDF database configuration file");
					repo_props = null;
				}
				try {
					repo_props.load(new FileInputStream(ses_props_file));
					
				} catch (Exception e) {
					logger.error(this + "Failed to load RDF database configuration file due to error: " + e.getMessage());
				}
				if (repo_props != null) {
								// extract parameters from supplied properties file
				
								JDBCdriver = repo_props.getProperty("jdbc_driver");	
								JDBCConnectionURL = repo_props.getProperty("jdbc_conn_url");
								User = repo_props.getProperty("jdbc_username");
								Password = repo_props.getProperty("jdbc_passwd");	
				
								RuleFile=	cx.getRealPath("WEB-INF/configuration/sesame/" +  repo_props.getProperty("rulefile"));
								RepoID = repo_props.getProperty("databaseid");	
								RepoName  = repo_props.getProperty("databasename");	

								logger.debug("Configuring "  +  RepoName.toString() + " repo with rule file: " + RuleFile.toString());
								SyncSail = 	repo_props.getProperty("syncSail");	
								PermSail = 	repo_props.getProperty("permSail");	
					} else {
								logger.error(this + "Failed to obtain JDBC connection or Sesame configuration parameters - Sesame will not be useable as an RDF database for the service.");
					}
			
			}
			else if (mode == RepositoryMode.DIRECT) {		
				
								System.out.println("API is being accessed directly by another application, configuring repo .... ");
						
								String ses_props_file = null;
								
									ses_props_file = "configuration/sesame/rdf_database.properties";
								
								try {
									repo_props.load(new FileInputStream(ses_props_file));
					
								} catch (Exception e) {
									logger.error(this + "Failed to load RDF database configuration file due to error: " + e.getMessage());
								}
								if (repo_props != null) {
											// extract parameters from supplied properties file
				
											JDBCdriver = repo_props.getProperty("jdbc_driver");	
											User = repo_props.getProperty("jdbc_username");
											Password = repo_props.getProperty("jdbc_passwd");	
				
											JDBCConnectionURL = repo_props.getProperty("jdbc_conn_url");
											RuleFile=	"configuration/sesame/" +  repo_props.getProperty("rulefile");
											RepoID = repo_props.getProperty("databaseid");	
											RepoName  = repo_props.getProperty("databasename");	
							
											System.out.println("Configuring "  +  RepoName + " repo with rule file: " + RuleFile.toString());
									
											SyncSail = 	repo_props.getProperty("syncSail");	
											PermSail = 	repo_props.getProperty("permSail");		
			
										} else {
											logger.error(this + "Failed to obtain JDBC connection or Sesame configuration parameters - Sesame will not be useable as an RDF database for the service.");
										}
			}
									
		
   			logger.debug(this + "Initialising Sesame Repository config object...");		
			//	create new RepositoryConfig with the supplied repository id and title
			RepositoryConfig config = new RepositoryConfig(RepoID,RepoName);
		 	SailConfig syncSail = new SailConfig(SyncSail);
	       	SailConfig permSail = new SailConfig(PermSail);
	
			logger.debug(this + "Configuring JDBC connection");
			logger.debug(this + " Setting JDBC connection parameters as driver " + JDBCdriver + " Connection url: " + JDBCConnectionURL + 
						"Username: " + User + "Password: " + Password);
					
			permSail.setParameter("jdbcDriver",JDBCdriver);
			permSail.setParameter("jdbcUrl",JDBCConnectionURL);
			permSail.setParameter("user",User);
			permSail.setParameter("password",Password);
					
 			logger.debug(this + "Configuring JDBC connection");
			
				//TODO - possibly remove these settings to allow for more flexible configuration
					
				// Specify inferencing. Note that the rule-file must be readable - currently
				// it is placed at the top of the hierarchy. May eventually put its name
				// and path into some configuration properties object
			permSail.setParameter("use-inferencer","org.openrdf.sesame.sailimpl.rdbms.CustomInferenceServices");
			logger.debug(this + "Configuring Sesame repository named: " + " with the rules file: " + RuleFile.toString());
		 		//Sesame's default rule file is entailment-rdf-mt-20030123.xml
		 		//We have a sample (entailment-skos-core-20040228.xml) (or later version) for SKOS
			permSail.setParameter("rule-file",RuleFile);
		 	
			// If in Standalone mode, you will need to put xercesImpl.jar in your classpath.
			 // If running inside a servlet container, most likely the xercesImpl.jar will already be in the classpath
			 permSail.setParameter("org.xml.sax.driver","org.apache.xerces.parsers.SAXParser");
		 	
		 	config.addSail(syncSail);
		 	config.addSail(permSail);

			 //		TODO - set read/write access for a user, rather than setting
			 // the repo as world readable or writeable
		 	config.setWorldReadable(true);
			 
		 	// set the config object;
			repo_config = config;
	}
	
	
	void add_to_nonprefLabel_array(String value) {
		//System.out.println("gonna add to pref label list array");
		non_pref_term_list.add(value);
		//System.out.println("array list size is now: " + non_pref_term_list.size());
	
	}			
	
	void add_to_concept_array(Concept item) {
		  // System.out.println("gonna add to concept array");
			concept_resultset.add(item);
		  //System.out.println("array list size is now: " + concept_resultset.size());
		
		}				

}
	