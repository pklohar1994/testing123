package org.w3.y2001.sw.Europe.skos.repository;

import java.util.*;

/**
 *  Repository Access Mode class
 * 
 * As used by AbstractRepo method configure
 * 
 * @author    Dave Beckett
 */
public final class RepositoryMode implements Comparable
{
	public static final RepositoryMode SERVLET = new RepositoryMode("Servlet");
	public static final RepositoryMode DIRECT = new RepositoryMode("Direct");
	
	public String toString() {
		return fName;
	}
	
	public int compareTo(Object aObject) {
	  return fOrdinal - ((RepositoryMode)aObject).fOrdinal;
	}

    /* private object data */
	private final  String fName;

	/* private constructor */
	private RepositoryMode (String aName) {
	  fName = aName;
	}

	/* private class data */
	private static int fNextOrdinal = 1;
	private final int fOrdinal = fNextOrdinal++;

    private static final RepositoryMode[] fValues = { SERVLET, DIRECT };
	
    /**
	* Allows user to iterate over all elements of the enumeration.
	*/
	public static final List VALUES = Collections.unmodifiableList(Arrays.asList(fValues));

}
