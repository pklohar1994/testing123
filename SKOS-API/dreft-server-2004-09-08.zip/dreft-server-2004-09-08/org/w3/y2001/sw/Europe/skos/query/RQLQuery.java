package org.w3.y2001.sw.Europe.skos.query;


import org.w3.y2001.sw.Europe.skos.Relation;
import org.w3.y2001.sw.Europe.skos.URI;

/**
 * RQL implementation of the AbstractQuery.
 * 
 * TODO: This class is incomplete / abandoned.  The SERQLQuery class implements more/most of the API now.
 *
 * @author Nikki Rogers
  */
public class RQLQuery extends AbstractQuery {

	protected String query_string;
	
	// TODO in this class we'll perform the mapping from any of the API
	// methods to the appropriate RQL query string
	
	public RQLQuery (){
		
	}
	
	public void parseQuery(URI uri_str) {
	
			//TODO this method should create the RQL statement from the
			// uri received and set query_string equal to this string
			//select * from  {X} @P {Y} where  X like \"http:/example.com/Concept/0002\"
			
			query_string = "SELECT * from  {X} @P {Y} where  X like \"" + uri_str.getUri().toString() + "\""; 
			this.setQuery(query_string);
	}	
		 
	public void parseQuery(String pref_label, URI thes) {
	
			//TODO this method should create the RQL statement from the
			//preferred label and thesaurus URI received and set query_string equal to this string
			// 
			// EG TARGET QUERY:
			// select X,@B,Q from  {X} @P {Y}, {X} @D {Z}, {X} @B {Q}	where  Y like "http:/example.com/thesaurus" and @P like "http://www.w3.org/2004/02/skos/core#inScheme" and @D like "http://www.w3.org/2004/02/skos/core#prefLabel" and Z like "English Cuisine"		
		
			query_string = "select X,@B,Q from  {X} @P {Y}, {X} @D {Z}, {X} @B {Q} where  Y like \"" + thes.getUri() + "\" and @P like \"http://www.w3.org/2004/02/skos/core#inScheme\" and @D like \"http://www.w3.org/2004/02/skos/core#prefLabel\" and Z like \"" + pref_label + "\"";
	 		this.setQuery(query_string);
	}		
	
	public void parseQuery(URI uri_str, Relation reln) {
	
			//TODO this method should create the RQL statement from the
			//preferred label and thesaurus URI received and set query_string equal to this string
			// 
			// EG TARGET QUERY:
			// select Y, @B, Q from  {X} @P {Y}, {Y} @B {Q} where  X like "http:/example.com/Concept/0003" and @P like "http://www.w3.org/2004/02/skos/core#related"
			query_string = "select Y, @B, Q from  {X} @P {Y}, {Y} @B {Q} where  X like \"" + uri_str.getUri()  + "\" and @P like \"" + reln.getLabel() + "\"";
			this.setQuery(query_string);
	}		
}		 
	   
	