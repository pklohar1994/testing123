/**
 * SKOSThesaurus.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package org.w3.y2001.sw.Europe.skos;

public interface SKOSThesaurus extends java.rmi.Remote {
    public org.w3.y2001.sw.Europe.skos.Concept getConcept(org.w3.y2001.sw.Europe.skos.URI in0) throws java.rmi.RemoteException;
    public org.w3.y2001.sw.Europe.skos.Concept[] getConceptsMatchingKeyword(java.lang.String in0) throws java.rmi.RemoteException;
    public org.w3.y2001.sw.Europe.skos.Concept[] getConceptsMatchingRegex(java.lang.String in0) throws java.rmi.RemoteException;
    public org.w3.y2001.sw.Europe.skos.Relation[] getSupportedSemanticRelations() throws java.rmi.RemoteException;
    public org.w3.y2001.sw.Europe.skos.Concept[] getConceptRelatives(org.w3.y2001.sw.Europe.skos.Concept in0, org.w3.y2001.sw.Europe.skos.Relation in1) throws java.rmi.RemoteException;
    public org.w3.y2001.sw.Europe.skos.Concept[] getAllConceptRelatives(org.w3.y2001.sw.Europe.skos.Concept in0) throws java.rmi.RemoteException;
    public org.w3.y2001.sw.Europe.skos.Concept[] getTopmostConcepts(org.w3.y2001.sw.Europe.skos.URI in0) throws java.rmi.RemoteException;
    public org.w3.y2001.sw.Europe.skos.Concept[] getTopConcepts(org.w3.y2001.sw.Europe.skos.Concept in0, org.w3.y2001.sw.Europe.skos.URI in1) throws java.rmi.RemoteException;
    public org.w3.y2001.sw.Europe.skos.Concept getConceptByPreferredLabel(java.lang.String in0, org.w3.y2001.sw.Europe.skos.URI in1) throws java.rmi.RemoteException;
    public org.w3.y2001.sw.Europe.skos.Concept getConceptByExternalID(java.lang.String in0, org.w3.y2001.sw.Europe.skos.URI in1) throws java.rmi.RemoteException;
    public org.w3.y2001.sw.Europe.skos.Concept[] getConceptsMatchingKeywordByThesaurus(java.lang.String in0, org.w3.y2001.sw.Europe.skos.URI in1) throws java.rmi.RemoteException;
    public org.w3.y2001.sw.Europe.skos.Concept[] getConceptsMatchingRegexByThesaurus(java.lang.String in0, org.w3.y2001.sw.Europe.skos.URI in1) throws java.rmi.RemoteException;
    public org.w3.y2001.sw.Europe.skos.Relation[] getSupportedSemanticRelationsByThesaurus(org.w3.y2001.sw.Europe.skos.URI in0) throws java.rmi.RemoteException;
    public org.w3.y2001.sw.Europe.skos.Concept[] getConceptRelativesByThesaurus(org.w3.y2001.sw.Europe.skos.Concept in0, org.w3.y2001.sw.Europe.skos.Relation in1, org.w3.y2001.sw.Europe.skos.URI in2) throws java.rmi.RemoteException;
    public org.w3.y2001.sw.Europe.skos.Concept[] getAllConceptRelativesByThesaurus(org.w3.y2001.sw.Europe.skos.Concept in0, org.w3.y2001.sw.Europe.skos.URI in1) throws java.rmi.RemoteException;
    public org.w3.y2001.sw.Europe.skos.ConceptRelatives[] getConceptRelativesByPath(org.w3.y2001.sw.Europe.skos.Concept in0, org.w3.y2001.sw.Europe.skos.Relation in1, org.w3.y2001.sw.Europe.skos.URI in2, int in3) throws java.rmi.RemoteException;
    public org.w3.y2001.sw.Europe.skos.ConceptRelatives[] getAllConceptsByPath(org.w3.y2001.sw.Europe.skos.Concept in0, org.w3.y2001.sw.Europe.skos.Relation in1, int in2) throws java.rmi.RemoteException;
}
