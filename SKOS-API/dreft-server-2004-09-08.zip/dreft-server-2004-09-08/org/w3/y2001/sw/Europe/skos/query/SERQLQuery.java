package org.w3.y2001.sw.Europe.skos.query;


import org.w3.y2001.sw.Europe.skos.Relation;
import org.w3.y2001.sw.Europe.skos.URI;

import org.apache.log4j.Logger;

/**
 *
 * SERQL query language implementation of the abstract query interface.  Forms query strings
 * that implement the required repository query, based on the method and parameter signature.
 * 
 * @author Nikki Rogers
  */
public class SERQLQuery extends AbstractQuery {

	protected String query_string;
	static Logger logger = Logger.getLogger(SERQLQuery.class.getName());
	
	public SERQLQuery () {
		
	}
	
	/**
	 * parseQuery: form a SERQL query for getting all properties of a given concept URI 
	 * @param uri_str concept URI
	 */
	public void parseQuery(URI uri_str) {
			//e.g.  SELECT * from  {X} P {Y} where  X =<!http:/example.com/Concept/0003>
			// or: SELECT <!http:/example.com/Concept/0003>,P,Y from {<!http:/example.com/Concept/0003>} P {Y}
			//query_string = "SELECT * from  {X} P {Y} where  X =<!" + uri_str.getUri().toString() + ">"; 
			logger.debug("THIS QUERY 1");	
			query_string = "SELECT <!" + uri_str.getUri().toString() + ">,P,Y from  {<!" + uri_str.getUri().toString() + ">} P {Y}"; 
			this.setQuery(query_string);
	}	
		 
	/**
	 * parseGetTopConceptsQuery: form a SERQL query for getting all the top concepts in a given thesaurus
     * @param uri_str the URI of the thesaurus
     */
	public void parseGetTopConceptsQuery(URI uri_str) {							
			logger.debug("THIS QUERY 2");
			query_string = "SELECT X,B,Q from {X} <rdf:type> {<skos:TopConcept>}, {X} <skos:inScheme> {<!" + uri_str.getUri().toString() + ">}, {X} B {Q} using namespace skos = <!http://www.w3.org/2004/02/skos/core#>"; 
			this.setQuery(query_string);
	}	
	
		 
	public void parseQuery(String property_value, URI thes, String property_type) {
	
			// this method creates the SERQL statement from the property value and property type (e.g. "prefLabel")
			// and thesaurus URI received and sets query_string equal to this string. The property_type
			// string should not include the namespace. 
			// TODO think about the namespace business!
			// 
			// EG TARGET QUERY GIVEN PREF LABEL:
			// select X,B,Q from  {X} P {Y}, {X} D {Z}, {X} B {Q}	where  Y like "http:/example.com/thesaurus" and P like "http://www.w3.org/2004/02/skos/core#inScheme" and D like "http://www.w3.org/2004/02/skos/core#prefLabel" and Z like "English Cuisine"	
			// OR MUCH QUICKER EXECUTION:
			// select X,B,Q from  {X} <!http://www.w3.org/2004/02/skos/core#inScheme> {Y}, {X} <!http://www.w3.org/2004/02/skos/core#prefLabel> {Z}, {X} B {Q}	where  Y like "http:/example.com/thesaurus" and Z like "English Cuisine"	
			
			// EG TARGET QUERY GIVEN EXTERNAL ID
			// select X,B,Q from  {X} <!http://www.w3.org/2004/02/skos/core#inScheme> {Y}, {X} <!http://www.w3.org/2004/02/skos/core#externalID> {Z}, {X} B {Q}	where  Y like "http:/example.com/thesaurus" and Z like "A.01.0001"	
			logger.debug("THIS QUERY 3");
			query_string = "select X,B,Q from  {X} <skos:inScheme> {Y}, {X} <skos:" + property_type + "> {Z}, {X} B {Q}	where  Y like \"" + thes.getUri() + "\" and Z like \"" + property_value + "\""+ " using namespace skos = <!http://www.w3.org/2004/02/skos/core#>";
			this.setQuery(query_string);
		}		
	
	/**
	 * parseQuery: form a SERQL query for getConceptRelatives(concept URI, relation)
	 * @param uri_str URI of the concept
	 * @param reln Relation to use in search
	 */
	public void parseQuery(URI uri_str, Relation reln) {
	
			// TODO this method should create the SERQL statement from the
			// preferred label and thesaurus URI received and set query_string equal to this string
			// 
			// EG TARGET QUERY:
			// SLOW: (because it uses the 'like' substring searcher)
			// select Y, B, Q from  {X} P {Y}, {Y} B {Q} where  X like "http:/example.com/Concept/0003" and P like "http://www.w3.org/2004/02/skos/core#related"	
			// OR MUCH QUICKER:
			// select Y, B, Q from  {X} <!http://www.w3.org/2004/02/skos/core#related> {Y}, {Y} B {Q} where X = <!http:/example.com/Concept/0003> 
			logger.debug("THIS QUERY 4");
			query_string = "select Y, B, Q from  {<!"  +   uri_str.getUri() + ">}  <!" +   reln.getLabel() + "> {Y}, {Y} B {Q}";
			this.setQuery(query_string);
	}		

	public void parseQuery(URI uri_str, Relation reln, URI uri_thes) {
	
			//this method should create the SERQL statement from the
			//uri of the concept, the relation and the thesaurus URI received and set query_string equal to this string
			// 
			// EG TARGET QUERY:
			// select Z,B,Q from  {X} <!http://www.w3.org/2004/02/skos/core#inScheme> {Y}, {X} <!http://www.w3.org/2004/02/skos/core#related> {Z}, {Z} B {Q} where  Y like "http:/example.com/thesaurus" and X = <!http:/example.com/Concept/0002> 	
			logger.debug("THIS QUERY 4b");
			query_string = "select Z, B, Q from  {<!"  +  uri_str.getUri() + ">}  <skos:inScheme> {<!"  +   uri_thes.getUri()  + ">}, {<!"  +  uri_str.getUri()  +  ">} <!" + reln.getLabel() + "> {Z}, {Z} B {Q}" + " using namespace skos = <!http://www.w3.org/2004/02/skos/core#>";
							
			this.setQuery(query_string);
	}			
	
	// TODO - add a method for prefLabel search - to search on index
	
	
	
	public void parseQuery(String keyword) {
	
			// EG TARGET QUERY:
			//select X, P, V from  {X} D {Y}, {X} P {V} where  Y like "*English meal*"
			logger.debug("THIS QUERY 5");
			query_string = "select X, P, V from  {X}  D {Y}, {X} P {V} where Y like \"*" + keyword  + "*\"";
			this.setQuery(query_string);
	}			
		
	public void parseQuery(String keyword, URI thes_uri) {
	
			// EG TARGET QUERY:
			// select X, P, V from  {X} D {Y}, {X} <!http://www.w3.org/2004/02/skos/core#inScheme> {Z}, {X} P {V} where  Y like "*English meal*" and Z = <!http:/example.com/thesaurus>
			logger.debug("THIS QUERY 6");
			query_string = "select X, P, V from  {X} D {Y}, {X} <skos:inScheme> {<!" + thes_uri.getUri() + ">}, {X} P {V} where  Y like \"*" + keyword  + "*\""+ " using namespace skos = <!http://www.w3.org/2004/02/skos/core#>";
			this.setQuery(query_string);
	}				

	/*
	 * form a SERQL query to find getTopConcepts(concept uri, thesaurus uri)
 	 */
	public void parseQuery(URI conc_uri, URI thes_uri) {
	
			//select Y, B, Q from {X} <!http://www.w3.org/2004/02/skos/core#broader> {Y}, {X} <!http://www.w3.org/2004/02/skos/core#inScheme> {Z},{Y} <rdf:type> {<skos:TopConcept>}, {Y} B {Q} where X = <!http:/example.com/Concept/0001> and Z = <!http:/example.com/thesaurus>
			// using namespace skos = <!http://www.w3.org/2004/02/skos/core#>
			logger.debug("THIS QUERY 7");
   			query_string = "select Y, B, Q from {X} <skos:broader> {Y}, {X} <skos:inScheme> {Z},{Y} <rdf:type> {<skos:TopConcept>}, {Y} B {Q} where X = <!" + conc_uri.getUri() + " and Z = <!" + thes_uri.getUri() + ">" + " using namespace skos = <!http://www.w3.org/2004/02/skos/core#>";
			this.setQuery(query_string);
	}					

	/*
	 * form a SERQL query to find all concepts immediately related to the given concept
	 */
	public void parseQuery(URI conc_uri, String relations) {
	
			//select Y, B, Q from {X} P {Y}, {Y} B {Q} where  X = <!http:/example.com/Concept/0001> and P = <!http://www.w3.org/2004/02/skos/core#broader> or P = <!http://www.w3.org/2004/02/skos/core#narrower> or P = <!http://www.w3.org/2004/02/skos/core#related> using namespace skos = <!http://www.w3.org/2004/02/skos/core#>
			// select Y, B, Q from {X} P {Y}, {Y} B {Q} where  X = <!http://www.eionet.eu.int/gemet/concept/500> and P = <!http://www.w3.org/2004/02/skos/core#broader> or P = <!http://www.w3.org/2004/02/skos/core#narrower> or P = <!http://www.w3.org/2004/02/skos/core#related> using namespace skos = <!http://www.w3.org/2004/02/skos/core#>
			//query_string = "select Y, B, Q from {X} P {Y}, {Y} B {Q} where  X = <!" + conc_uri.getUri() + " and P = <!http://www.w3.org/2004/02/skos/core#broader> or P = <!http://www.w3.org/2004/02/skos/core#narrower> or P = <!http://www.w3.org/2004/02/skos/core#related> using namespace skos = <!http://www.w3.org/2004/02/skos/core#>";
			
			//e.g. select Y, B, Q from {<!http:/example.com/Concept/0001>}  P {Y}, {Y} B {Q} where P = <!http://www.w3.org/2004/02/skos/core#broader> or P = <!http://www.w3.org/2004/02/skos/core#narrower> or P = <!http://www.w3.org/2004/02/skos/core#related> using namespace skos = <!http://www.w3.org/2004/02/skos/core#>
			logger.debug("THIS QUERY 8");
			query_string = "select Y, B, Q from {<!" + conc_uri.getUri() +">} P {Y}, {Y} B {Q} where P = <!http://www.w3.org/2004/02/skos/core#broader> or P = <!http://www.w3.org/2004/02/skos/core#narrower> or P = <!http://www.w3.org/2004/02/skos/core#related> using namespace skos = <!http://www.w3.org/2004/02/skos/core#>";
			this.setQuery(query_string);
	}	
		/*
		 * form a SERQL query to find all concepts immediately related to the given concept in a certain thesaurus scheme
		 */
		public void parseQuery(URI conc_uri, String relations, URI thes_uri) {
	
				//select Y, B, Q from {X} P {Y}, {Y} B {Q}, {X} <!http://www.w3.org/2004/02/skos/core#inScheme> {<!http:/example.com/thesaurus>}
			// where  X = <!http:/example.com/Concept/0001> and P = <!http://www.w3.org/2004/02/skos/core#broader> or P = <!http://www.w3.org/2004/02/skos/core#narrower> or P = <!http://www.w3.org/2004/02/skos/core#related> using namespace skos = <!http://www.w3.org/2004/02/skos/core#>	
			logger.debug("THIS QUERY 9");
			query_string = "select Y, B, Q from {<!" + conc_uri.getUri() +">}  P {Y}, {Y} B {Q} where  P = <!http://www.w3.org/2004/02/skos/core#broader> or P = <!http://www.w3.org/2004/02/skos/core#narrower> or P = <!http://www.w3.org/2004/02/skos/core#related> using namespace skos = <!http://www.w3.org/2004/02/skos/core#>";
			this.setQuery(query_string);
		}	
		
		public void parseExactQuery(URI thes, String pref_label) {
	
			// this method creates the SERQL statement Thesaurus URI and the preferred label string.
			// e.g. query, where we search on the index of the literal values for preferred literals
			// select X,B,Q from  {X} <skos:inScheme> {<!http:/example.com/thesaurus>}, {X} <skos:prefLabel> {"English cuisine"}, {X} B {Q}	using namespace skos = <!http://www.w3.org/2004/02/skos/core#>
			// Note: this is case sensitive. An alternative to using the operation that calls this parse query method is to 
			// use the keyword search operation - but this is very lengthy on the server and may therefore cause a timeout on the client side.
			logger.debug("THIS QUERY 10");
			query_string = "select X,B,Q from  {X} <skos:inScheme>  {<!" + thes.getUri() + ">}, {X} <skos:prefLabel> {\"" + pref_label + "\"}, {X} B {Q} using namespace skos = <!http://www.w3.org/2004/02/skos/core#>";
			//query_string = "select X,B,Q from  {X} <skos:inScheme> {Y}, {X} <skos:" + property_type + "> {Z}, {X} B {Q}	where  Y like \"" + thes.getUri() + "\" and Z like \"" + property_value + "\""+ " using namespace skos = <!http://www.w3.org/2004/02/skos/core#>";
			this.setQuery(query_string);
		}		
		

}		 
	   
	