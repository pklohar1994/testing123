package org.w3.y2001.sw.Europe.skos;


/**
 *
 * @author Nikki Rogers
  */
public class StandaloneServiceImplTest {

	/**
	 * This class is useful for developing and testing the SKOS API implementation directly, as opposed to when it is
	 * embedded in Axis for example.
	 * 
	 * @return 
	 * @exception 
	 * 
	  **/
	public static void main(String [] args) {
		
	
		try {
	
		// calls can be made to the appropriate search method - to return singleton/array concepts/relations 
		
		
		/*
		// XXXXXXXXXXXXXXX GET AN ARRAY OF CONCEPTS XXXXXXXXXXXXXXXXX
		
		//this hardcoded query should return 2 results - ie 2 concepts, as beans in a concept bean array
		 query.setQuery("select X, @PROPERTY, VALUE from  {X : core:Concept } core:broader {Y}, {X} @PROPERTY {VALUE} where  Y like \"http:/example.com/Concept/0002\" using namespace core = http://www.w3.org/2004/02/skos/core#");
				
		Concept[]result_concepts = repo.doSearch_for_concepts(query);
		System.out.println("XXXXXXXXXXXXXXXXXXX RESULTS TO SCREEN XXXXXXXXXXX");
		for (int item = 0; item < result_concepts.length; item++) {
			System.out.println("Concept result: ");		
				System.out.println("Concept preferred label: " + result_concepts[item].getPreferredLabel().toString());
						for (int labels = 0; labels < result_concepts[item].getNonPreferredLabels().length; labels++) {
							System.out.println("Concept non-preferred label: " + result_concepts[item].getNonPreferredLabels(labels).toString());
						}
				
		}
	
		
		// XXXXXXXXXXXXXXX GET A SINGLE CONCEPT XXXXXXXXXXXXXXXXX
		// the singleton search for a concept test method:	
		//AbstractQuery query = (AbstractQuery) query_.newInstance();
		// this harcoded query should return one concept
		System.out.println("XXXXXXXXXXXXXXXXXXXGONNA RUN SINGLETON QUERY NOW XXXXXXXXXXX");
		//query.setQuery("select * from  {X} @P {Y} where  X like \"http:/example.com/Concept/0002\"");
		Concept result_concept = repo.doSearch_for_concept(query);
		System.out.println("XXXXXXXXXXXXXXXXXXX RESULTS TO SCREEN XXXXXXXXXXX");
		System.out.println("Concept preferred label: " + result_concept.getPreferredLabel().toString());
		for (int labels = 0; labels < result_concept.getNonPreferredLabels().length; labels++) {
								System.out.println("Concept non-preferred label: " + result_concept.getNonPreferredLabels(labels).toString());
		}
		*/
		
		
		// XXXXXXXXXXXXXXX GET RELATIONS XXXXXXXXXXXXXXXXX
		// TODO - re the 'getsupportedsemanticrelations' method
		
	

		// TODO continue mplementing the various API methods here - 
		// requires implementing methods in the Query objects - namely the RQLQuery object at present
		
		// XXXXXXXXXX  Get a concept by a known URI XXXXXXXXXXX
		System.out.println("XXXXXXXXXXXXXXXXXXX GONNA TRY GET CONCEPT BY URI XXXXXXXXXXX");
		URI test_uri = new URI();
		test_uri.setUri("http:/example.com/Concept/0003");
				
		System.out.println("Gonna create a new demo service directly.");
		DemoService demo = new DemoService("direct");
		System.out.println("Will now call the getConcept method on the service.");
		Concept concept_by_uri = demo.getConcept(test_uri);
		if (concept_by_uri != null) {
		System.out.println("XXXXXXXXXXXXXXXXXXX RESULTS TO SCREEN XXXXXXXXXXX");
				System.out.println("Concept preferred label: " +  concept_by_uri .getPreferredLabel().toString());
				for (int labels = 0; labels <  concept_by_uri .getNonPreferredLabels().length; labels++) {
										System.out.println("Concept non-preferred label: " +  concept_by_uri .getNonPreferredLabels(labels).toString());
				}
		}
				   else {
						   System.out.println("No results match your query.");
				   }
					
		} 	catch ( java.lang.IndexOutOfBoundsException ioobe)
		{
	
		}
		catch(Exception e)
				{
		
				System.out.println(e);
				}
		
		try {
		System.out.println("XXXXXXXXXXXXXXXXXXX GONNA TRY GET RELATED CONCEPTS BY PATH XXXXXXXXXXX");

			/*
			 * 		Concept dummy_concept = new Concept();
				URI conc_uri = new URI();
				//conc_uri.setUri("http:/example.com/Concept/0002");
				conc_uri.setUri("http:/example.com/Concept/0001");
				dummy_concept.setUri(conc_uri);
	
			 */
			URI conc_uri = new URI();
			conc_uri.setUri("http:/example.com/Concept/2000");
			System.out.println("Concept uri is: " + conc_uri.getUri());
			
			
			URI thes_uri = new URI();
			thes_uri.setUri("http:/example.com/thesaurus");
	
						
			Relation rln_ = new Relation();
					//rln.setLabel("http://www.w3.org/2004/02/skos/core#related");
			rln_.setLabel("http://www.w3.org/2004/02/skos/core#narrower");	
	
			Concept dum_conc = new Concept();
			dum_conc.setUri(conc_uri);
			System.out.println("Gonna create a new demo service directly.");
			System.out.println("Concept is known as: " + dum_conc.getUri().getUri());
			DemoService demo = new DemoService("direct");
			System.out.println("Will now call the getConceptRelativesbyPath method on the service.");
			demo.getConceptRelativesByPath(dum_conc, rln_, thes_uri, 3);
		}
			/*
			if (concept_by_uri != null) {
			System.out.println("XXXXXXXXXXXXXXXXXXX RESULTS TO SCREEN XXXXXXXXXXX");
					System.out.println("Concept preferred label: " +  concept_by_uri .getPreferredLabel().toString());
					for (int labels = 0; labels <  concept_by_uri .getNonPreferredLabels().length; labels++) {
											System.out.println("Concept non-preferred label: " +  concept_by_uri .getNonPreferredLabels(labels).toString());
					}
			}
					   else {
							   System.out.println("No results match your query.");
					   }
					
			} 

			catch ( java.lang.IndexOutOfBoundsException ioobe)
			{
	
			} */
			catch(Exception e)
					{
		
					System.out.println(e);
					}
		


		// XXXXXXXXXX  Get a concept by preferred Label and thesaurus XXXXXXXXXXX
		System.out.println("XXXXXXXXXXXXXXXXXXX GONNA TRY GET CONCEPT BYPREF LABEL & THE URI XXXXXXX");
		URI thes_uri = new URI();
		thes_uri.setUri("http:/example.com/thesaurus");
		
		DemoService demo = new DemoService("direct");
		Concept concept_by_prefL = demo.getConceptByPreferredLabel("English Cuisine", thes_uri);
		if (concept_by_prefL != null) {
		System.out.println("XXXXXXXXXXXXXXXXXXX RESULTS TO SCREEN XXXXXXXXXXX");
				System.out.println("Concept preferred label: " +  concept_by_prefL .getPreferredLabel().toString());
				for (int labels = 0; labels <  concept_by_prefL .getNonPreferredLabels().length; labels++) {
										System.out.println("Concept non-preferred label: " +  concept_by_prefL .getNonPreferredLabels(labels).toString());
				}
		}
				   else {
						   System.out.println("No results match your query.");
				   }
				   
				   
		//	XXXXXXXXXX  Get a concept by external ID and thesaurus ID XXXXXXXXXXX
			 System.out.println("XXXXXXXXXXXXXXXXXXX GONNA TRY GET CONCEPT EXTERNAL ID & THE URI XXXXXXX");
			 // Use earlier settings for thesaurus uri
			 //URI thes_uri = new URI();
			 //thes_uri.setUri("http:/example.com/thesaurus");
		
			 //DemoService demo = new DemoService();
			 Concept concept_by_extID = demo.getConceptByExternalID("A.01.0001", thes_uri);
			 if (concept_by_extID != null) {
					 System.out.println("XXXXXXXXXXXXXXXXXXX RESULTS TO SCREEN XXXXXXXXXXX");
					 System.out.println("Concept preferred label: " +  concept_by_extID .getPreferredLabel().toString());
					 for (int labels = 0; labels <  concept_by_extID .getNonPreferredLabels().length; labels++) {
											 System.out.println("Concept non-preferred label: " +  concept_by_extID .getNonPreferredLabels(labels).toString());
					 }
			 }
			else {
					System.out.println("No results match your query.");
			}
						
			//	Get a list of all concept relatives. TODO: this one relies
			 // on repeated applications of "Get a list of the concept relatives with a semantic relation",
			 // for all the types of relations.
			 // Concept[]  result_rel_concepts = getAllConceptRelatives(Concept concept)
		 
		 		// get concept relatives for a given concept and a given relation
				System.out.println("XXXXXXXXXXXXXXXXXXX GONNA TRY GET CONCEPTS BY URI & SOME RELATION XXXXXXX");
				Concept dummy_concept = new Concept();
				URI conc_uri = new URI();
				//conc_uri.setUri("http:/example.com/Concept/0002");
				conc_uri.setUri("http:/example.com/Concept/0001");
				dummy_concept.setUri(conc_uri);
				
				Relation rln = new Relation();
				//rln.setLabel("http://www.w3.org/2004/02/skos/core#related");
				rln.setLabel("http://www.w3.org/2004/02/skos/core#broader");
				//DemoService demo_s= new DemoService();
				Concept[] concepts_by_reln = demo.getConceptRelatives(dummy_concept, rln);
				if (concepts_by_reln != null) {
				for (int item = 0; item < concepts_by_reln.length; item++) {
							System.out.println("Concept result: ");		
							System.out.println("Concept preferred label: " + concepts_by_reln[item].getPreferredLabel().toString());
									for (int labels = 0; labels < concepts_by_reln[item].getNonPreferredLabels().length; labels++) {
												System.out.println("Concept non-preferred label: " + concepts_by_reln[item].getNonPreferredLabels(labels).toString());
									}
				}
				}
			   else {
									   System.out.println("No results match your query.");
			   }
			
//		Get a list of all concept relatives. TODO: this one relies
				 // on repeated applications of "Get a list of the concept relatives with a semantic relation",
				 // for all the types of relations.
				 // Concept[]  result_rel_concepts = getAllConceptRelatives(Concept concept)
		 
					// get concept relatives for a given concept and a given relation
					System.out.println("XXXXXXXXXXXXXXXXXXX GONNA TRY GET CONCEPTS BY URI & SOME RELATION XXXXXXX");
					Concept dummy_concept2 = new Concept();
					URI conc_uri2 = new URI();
					//conc_uri.setUri("http:/example.com/Concept/0002");
					conc_uri2.setUri("http:/example.com/Concept/0081");
					dummy_concept2.setUri(conc_uri2);
				
					Relation rln2 = new Relation();
					//rln.setLabel("http://www.w3.org/2004/02/skos/core#related");
					rln2.setLabel("http://www.w3.org/2004/02/skos/core#broader");
					//DemoService demo_s= new DemoService();
					Concept[] concepts_by_reln2 = demo.getConceptRelatives(dummy_concept2, rln2);
					if (concepts_by_reln2 != null) {
					for (int item = 0; item < concepts_by_reln2.length; item++) {
								System.out.println("Concept result: ");		
								System.out.println("Concept preferred label: " + concepts_by_reln2[item].getPreferredLabel().toString());
										for (int labels = 0; labels < concepts_by_reln2[item].getNonPreferredLabels().length; labels++) {
													System.out.println("Concept non-preferred label: " + concepts_by_reln2[item].getNonPreferredLabels(labels).toString());
										}
					}
					}
				   else {
										   System.out.println("No results match your query.");
				   }	
				
						// get concept relatives for a given concept, thesaurus and a given relation
						System.out.println("XXXXXXXXXXXXXXXXXXX GONNA TRY GET CONCEPTS VIA URI & SOME RELATION IN SOME THESAURUS XXXXXXX");
						//Concept dummy_concept = new Concept();
						//URI conc_uri = new URI();
						//conc_uri.setUri("http:/example.com/Concept/0002");
						conc_uri.setUri("http:/example.com/Concept/0001");
						dummy_concept.setUri(conc_uri);
				
						//Relation rln = new Relation();
						//rln.setLabel("http://www.w3.org/2004/02/skos/core#related");
						rln.setLabel("http://www.w3.org/2004/02/skos/core#broader");
						//DemoService demo_s= new DemoService();
						Concept[] concepts_by_relation = demo.getConceptRelativesByThesaurus(dummy_concept, rln,thes_uri);
						if (concepts_by_relation != null) {
						for (int item = 0; item < concepts_by_reln.length; item++) {
									System.out.println("Concept result: ");		
									System.out.println("Concept preferred label: " + concepts_by_relation[item].getPreferredLabel().toString());
											for (int labels = 0; labels < concepts_by_relation[item].getNonPreferredLabels().length; labels++) {
														System.out.println("Concept non-preferred label: " + concepts_by_relation[item].getNonPreferredLabels(labels).toString());
											}
						}
						}
					   else {
											   System.out.println("No results match your query.");
					   }	
				
				
				//getAllConceptRelatives
		System.out.println("XXXXXXXXXXXXXXXXXXX GONNA TRY GET ALL CONCEPT RELATIVES BY URI XXXXXXX");
					Concept dummy_concept3 = new Concept();
					URI conc_uri3 = new URI();
					//conc_uri.setUri("http:/example.com/Concept/0002");
					conc_uri3.setUri("http:/example.com/Concept/0081");
					dummy_concept3.setUri(conc_uri3);
				
					//DemoService demo_s= new DemoService();
					Concept[] concepts_by_reln3 = demo.getAllConceptRelatives(dummy_concept3);
					if (concepts_by_reln3 != null) {
					for (int item = 0; item < concepts_by_reln3.length; item++) {
								System.out.println("Concept result: ");		
								System.out.println("Concept preferred label: " + concepts_by_reln3[item].getPreferredLabel().toString());
										for (int labels = 0; labels < concepts_by_reln3[item].getNonPreferredLabels().length; labels++) {
													System.out.println("Concept non-preferred label: " + concepts_by_reln3[item].getNonPreferredLabels(labels).toString());
										}
					}
					}
				   else {
										   System.out.println("No results match your query.");
				   }	
				
	
		
		//getAllConceptRelativesbyThes
		System.out.println("XXXXXXXXXXXXXXXXXXX GONNA TRY GET ALL CONCEPT RELATIVES BY URI & THESAURUS XXXXXXX");
			Concept dummy_concept4 = new Concept();
			URI conc_uri4 = new URI();
			//conc_uri.setUri("http:/example.com/Concept/0002");
			conc_uri4.setUri("http:/example.com/Concept/0081");
			dummy_concept4.setUri(conc_uri3);
				
			//DemoService demo_s= new DemoService();
			Concept[] concepts_by_reln4 = demo.getAllConceptRelativesByThesaurus(dummy_concept4,thes_uri);
			if (concepts_by_reln4 != null) {
			for (int item = 0; item < concepts_by_reln4.length; item++) {
						System.out.println("Concept result: ");		
						System.out.println("Concept preferred label: " + concepts_by_reln4[item].getPreferredLabel().toString());
								for (int labels = 0; labels < concepts_by_reln4[item].getNonPreferredLabels().length; labels++) {
											System.out.println("Concept non-preferred label: " + concepts_by_reln4[item].getNonPreferredLabels(labels).toString());
								}
			}
			}
		   else {
								   System.out.println("No results match your query.");
		   }	
				
	
				
		System.out.println("XXXXXXXXXXXXXXXXXXX GONNA TRY GET CONCEPTS BY SUBSTRING MATCH ON GIVEN KEYWORD XXXXXXX");
				Concept[] concepts_ = demo.getConceptsMatchingKeyword("English meal");
			if (concepts_ != null) {
			for (int item = 0; item < concepts_.length; item++) {
						System.out.println("Concept result: ");		
						System.out.println("Concept preferred label: " + concepts_[item].getPreferredLabel().toString());
								for (int labels = 0; labels < concepts_[item].getNonPreferredLabels().length; labels++) {
											System.out.println("Concept non-preferred label: " + concepts_[item].getNonPreferredLabels(labels).toString());
								}
			}
			}
		   else {
								   System.out.println("No results match your query.");
		   }
				
		
		System.out.println("XXXXXXXXXXXXXXXXXXX GONNA TRY GET CONCEPTS BY SUBSTRING MATCH ON GIVEN KEYWORD & FOR GIVEN THESAURUS XXXXXXX");
			concepts_ = null;
			concepts_ = demo.getConceptsMatchingKeywordByThesaurus("English meal", thes_uri);
			if (concepts_ != null) {
			for (int item = 0; item < concepts_.length; item++) {
						System.out.println("Concept result: ");		
						System.out.println("Concept preferred label: " + concepts_[item].getPreferredLabel().toString());
								for (int labels = 0; labels < concepts_[item].getNonPreferredLabels().length; labels++) {
											System.out.println("Concept non-preferred label: " + concepts_[item].getNonPreferredLabels(labels).toString());
								}
			}
			}
		   else {
								   System.out.println("No results match your query.");
		   }
				
		System.out.println("XXXXXXXXXXXXXXXXXXX GONNA TRY GET SUPPORTED SEMANTIC RELATIONS XXXXXXX");
					
					Relation [] relations_ =  demo.getSupportedSemanticRelations();
					if (relations_ != null) {
					for (int item = 0; item < relations_.length; item++) {
								System.out.println("Relation result: ");		
								System.out.println("Relation URI: " + relations_[item].getUri().getUri());
					}			
					}
				   else {
										   System.out.println("No results match your query.");
				   }	
				
		System.out.println("XXXXXXXXXXXXXXXXXXX TESTING COMPLETE XXXXXXX");		
				
	}	
}
	