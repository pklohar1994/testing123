package org.w3.y2001.sw.Europe.skos.repository;

import org.w3.y2001.sw.Europe.skos.Concept;
import org.w3.y2001.sw.Europe.skos.Relation;
import org.w3.y2001.sw.Europe.skos.query.AbstractQuery;
import org.w3.y2001.sw.Europe.skos.repository.RepositoryMode;

/**
 *  Abstract Repository class
 * 
 * Provides the abstract methods for accessing a repository of SKOS data independent of the implementation.
 *
 * @author    Nikki Rogers
 */
public abstract class AbstractRepo
{
	protected String repo_id;
	protected Concept concept_result;
	protected Relation[] relation_results;
	protected Concept[]  concept_results;
	
	//	TODO might need a properties object to hold data about this repo
	//  this.options = new Properties();
	
	public AbstractRepo() {
		
	}
		   
	public AbstractRepo(String repo_id)
	{
		this.repo_id =repo_id;
	}
     
	public Concept[] doSearch_for_concepts(AbstractQuery query)
	{
		return concept_results;
	}

	public Relation[] doSearch_for_relations(AbstractQuery query)
	{
		return  relation_results;
	}

	public Concept doSearch_for_concept(AbstractQuery query)
	{
		return concept_result;
	}
 /**
   * An application-specific access mode such as indiciating servlet context or standalone ("direct access")
   * @param mode repository access mode such as SERVLET or DIRECT
   */
	public abstract void configure(RepositoryMode mode);
	{
	}
}

