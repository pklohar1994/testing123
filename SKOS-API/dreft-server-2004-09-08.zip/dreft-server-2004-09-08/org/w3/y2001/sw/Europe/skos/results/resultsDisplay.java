		package org.w3.y2001.sw.Europe.skos.results;

//		   Apache Axis imports

		import org.apache.axis.MessageContext;
		
		import javax.xml.soap.SOAPMessage;
		import javax.xml.soap.SOAPPart;
		import javax.xml.soap.SOAPEnvelope;
		import javax.xml.soap.SOAPBody;

		import org.apache.log4j.Logger;

		import org.w3.y2001.sw.Europe.skos.Concept;	
		import org.w3.y2001.sw.Europe.skos.ConceptRelatives;	
		import org.w3.y2001.sw.Europe.skos.Relation;	

		/**
		 *
		 * @author Nikki Rogers (nikki.rogers@bristol.ac.uk)
		 * 
		 * This class is currently used by the test client as it has generic methods for dumping 
		 * out results to a user when testing is done from the command line
		 *
		 *		 */

		public class resultsDisplay
		{

		public void result_to_screen(Concept curr_concept, MessageContext msgctxt) {
		
			// Now let's check we can dump out the data for that concept
			try {
					System.out.println("We will now try to extract concept data received from the service:");
					
									
					int i = 0;
							
					System.out.println("Concept preferred label: " + curr_concept.getPreferredLabel());	
					if (curr_concept.getNonPreferredLabels() != null)  {
					
							while (i < curr_concept.getNonPreferredLabels().length) {
										System.out.println("Concept Non preferred label: " + curr_concept.getNonPreferredLabels(i));
										i++;
							}
					}
					System.out.println("SUCCESS: No client-side parsing problems. Here is the full SOAP message for your information: " + curr_concept.getPreferredLabel());	
											try {
																	// drill down to the contents of the soap body
																	SOAPMessage msg = msgctxt.getMessage();
																	SOAPPart sp = msg.getSOAPPart();  
																	SOAPEnvelope se = sp.getEnvelope();  
																	SOAPBody sb = se.getBody();
																	// this prints out the message body just as received in the soap envelope
																	System.out.println(sb);      
														} catch (Exception e) {

															System.out.println("Problem processing the returned SOAP message" + e);
														}
					
					
			} catch (Exception oe) {
					System.out.println("There was a problem extracting data returned from service: " + oe);
								try {
														// drill down to the contents of the soap body
														SOAPMessage msg = msgctxt.getMessage();
														SOAPPart sp = msg.getSOAPPart();  
														SOAPEnvelope se = sp.getEnvelope();  
														SOAPBody sb = se.getBody();
														// this prints out the message body just as received in the soap envelope
														System.out.println("To help diagnose the problem, here's the body of the soap message returned from the service:");
														System.out.println(sb);      
											} catch (Exception e) {

												System.out.println("Problem processing the returned SOAP message" + e);
											}
		
				 			 
			}
		}
		public void results_to_screen(Concept[] result_concs,  MessageContext msgctxt) {
		//			lets see if we can print out the concepts we got back from the service now		
				 try {
				 System.out.println("We will now look at the concept data returned from the service.");
				 if (result_concs.length > 0) {
					 for (int item = 0; item < result_concs.length; item++) {
								 System.out.println("Concept result " + (item+1) + " : ");		
								 System.out.println("Concept preferred label: " + result_concs[item].getPreferredLabel());
								 System.out.println("Concept URI: " + result_concs[item].getUri().getUri());		
										 if (result_concs[item].getNonPreferredLabels() != null) {
											 int i = 0;
											 while (i < result_concs[item].getNonPreferredLabels().length) {
														 System.out.println("Concept non-preferred label: " + result_concs[item].getNonPreferredLabels(i));
														 i++;
											 }								
										 } else
										 {
											 System.out.println("This concept has no associated non-preferred labels.");
										 }
					 }
					System.out.println("SUCCESS: No client-side parsing problems. Here is the full SOAP message for your information: ");	
											try {
																	// drill down to the contents of the soap body
																	SOAPMessage msg = msgctxt.getMessage();
																	SOAPPart sp = msg.getSOAPPart();  
																	SOAPEnvelope se = sp.getEnvelope();  
																	SOAPBody sb = se.getBody();
																	// this prints out the message body just as received in the soap envelope
																	System.out.println(sb);      
														} catch (Exception e) {

															System.out.println("Problem processing the returned SOAP message" + e);
														}
	
				 }
	
				 } catch (Exception oe) {
					 System.out.println("There was a problem extracting data returned from service: " + oe);
								 try {
														 // drill down to the contents of the soap body
														 SOAPMessage msg = msgctxt.getMessage();
														 SOAPPart sp = msg.getSOAPPart();  
														 SOAPEnvelope se = sp.getEnvelope();  
														 SOAPBody sb = se.getBody();
														 // this prints out the message body just as received in the soap envelope
														 System.out.println("To help diagnose the problem, here's the body of the soap message returned from the service:");
														 System.out.println(sb);      
											 } catch (Exception e) {

												 System.out.println("Problem processing the returned SOAP message" + e);
											 }
				 }
			
			
		}
		
		public void results_to_screen(ConceptRelatives[] result_concs,  MessageContext msgctxt) {
		//			lets see if we can print out the concepts we got back from the service now		
				 try {
				 System.out.println("We will now look at the concept data returned from the service.");
				 if (result_concs != null) {
				 for (int level = 0; level < result_concs.length; level++) {
							 System.out.println("Retrieving result concept relatives at level  " + (level+1));
							 Concept[] result_relatives;
							 result_relatives = result_concs[level].getConcepts();		
									 for (int conc = 0; conc < result_relatives.length; conc++) {
											 System.out.println("Concept preferred label: " + result_relatives[conc].getPreferredLabel());
											 System.out.println("Concept URI: " + result_relatives[conc].getUri().getUri());		
											 if (result_relatives[conc].getNonPreferredLabels() != null) {
													 int i = 0;
													 while (i < result_relatives[conc].getNonPreferredLabels().length) {
														 System.out.println("Concept non-preferred label: " + result_relatives[conc].getNonPreferredLabels(i));
														 i++;
													 }								
											 } else
											 {
												 System.out.println("This concept has no associated non-preferred labels.");
											 }
									 }
				 }
			 
					System.out.println("SUCCESS: No client-side parsing problems. Here is the full SOAP message for your information: ");	
											try {
																	// drill down to the contents of the soap body
																	SOAPMessage msg = msgctxt.getMessage();
																	SOAPPart sp = msg.getSOAPPart();  
																	SOAPEnvelope se = sp.getEnvelope();  
																	SOAPBody sb = se.getBody();
																	// this prints out the message body just as received in the soap envelope
																	System.out.println(sb);      
														} catch (Exception e) {

															System.out.println("Problem processing the returned SOAP message" + e);
														}
	
				 }
				 }catch (Exception oe) {
					 System.out.println("There was a problem extracting data returned from service: " + oe);
								 try {
														 // drill down to the contents of the soap body
														 SOAPMessage msg = msgctxt.getMessage();
														 SOAPPart sp = msg.getSOAPPart();  
														 SOAPEnvelope se = sp.getEnvelope();  
														 SOAPBody sb = se.getBody();
														 // this prints out the message body just as received in the soap envelope
														 System.out.println("To help diagnose the problem, here's the body of the soap message returned from the service:");
														 System.out.println(sb);      
											 } catch (Exception e) {

												 System.out.println("Problem processing the returned SOAP message" + e);
											 }
				 }
			
			
		} // end method				
		
		
		public void results_to_screen(Relation[] results,  MessageContext msgctxt) {
		//			lets see if we can print out the concepts we got back from the service now		
				 try {
				 System.out.println("We will now look at the Relations data returned from the service.");
				 if (results != null) {
		 		
					for (int item = 0; item < results.length; item++) {
								System.out.println("Relation result: ");		
								System.out.println("Relation URI: " + results[item].getUri().getUri());
				
					}

		 		}
			 
					System.out.println("SUCCESS: No client-side parsing problems. Here is the full SOAP message for your information: ");	
											try {
																	// drill down to the contents of the soap body
																	SOAPMessage msg = msgctxt.getMessage();
																	SOAPPart sp = msg.getSOAPPart();  
																	SOAPEnvelope se = sp.getEnvelope();  
																	SOAPBody sb = se.getBody();
																	// this prints out the message body just as received in the soap envelope
																	System.out.println(sb);      
														} catch (Exception e) {

															System.out.println("Problem processing the returned SOAP message" + e);
														}
	
				 
				 }catch (Exception oe) {
					 System.out.println("There was a problem extracting data returned from service: " + oe);
								 try {
														 // drill down to the contents of the soap body
														 SOAPMessage msg = msgctxt.getMessage();
														 SOAPPart sp = msg.getSOAPPart();  
														 SOAPEnvelope se = sp.getEnvelope();  
														 SOAPBody sb = se.getBody();
														 // this prints out the message body just as received in the soap envelope
														 System.out.println("To help diagnose the problem, here's the body of the soap message returned from the service:");
														 System.out.println(sb);      
											 } catch (Exception e) {

												 System.out.println("Problem processing the returned SOAP message" + e);
											 }
				 }
			
			
		} // end method				
		
		
		
		
	}