		package org.w3.y2001.sw.Europe.skos;

		import org.apache.axis.MessageContext;
		import org.apache.log4j.Logger;
		import java.net.URL;
		import  org.w3.y2001.sw.Europe.skos.results.resultsDisplay;
		/**
		 *
		 * @author Nikki Rogers (nikki.rogers@bristol.ac.uk)
		 */

		public class skostestsuiteclient
		{

		static Logger logger = Logger.getLogger(skostestclient_getConcept.class.getName());
		static SKOSThesaurusServiceLocator service;
		static MessageContext msgctxt = null;
		static Concept curr_concept = null;
	
		
		//		SERVICE-SPECIFIC PARAMETERS
		//static final String service_url = "http://localhost:8081/axis/services/SKOSThesaurusService";
		static final String service_url = "http://thes.ilrt.bris.ac.uk/SKOSThesaurusService";
		static final String service_name = "SKOSThesaurusService";

		//		SOME "DUMMY" DATA WITH WHICH TO TEST THE SERVICE
		// the sample_uri will be used in the getConcept operation
 		//static final String sample_uri = "http:/example.com/Concept/0003";
		//a sample for the demo skos service is "http://www.eionet.eu.int/gemet/concept/15020"
		static final String sample_uri = "http://www.eionet.eu.int/gemet/concept/15020";
	//	static final String sample_uri = "http://www.eionet.eu.int/gemet/concept/500";

				
		//static final String sample_thes_uri = "http:/example.com/thesaurus";
		// a sample for the demo skos service is "http://www.eionet.eu.int/gemet/2004/06/gemet-schema.rdf"
		static final String sample_thes_uri = "http://www.eionet.eu.int/gemet/2004/06/gemet-schema.rdf";
		
		static final String sample_extid = "A.01.0232";
		// no sample in the demo skos service
		
		//static final String sample_pref_label_ = "English cuisine";
		//a sample for the demo skos service is "insulating material" (although currently a problem as it needs @en appended
		static final String sample_pref_label_ = "building material" + "@en";

		static final String sample_keyword = "English";
		//static final String sample_keyword = "insulating";
			
		static final String sample_relation = "http://www.w3.org/2004/02/skos/core#broader";
		
								
		/** This class uses the generated stubs to test the suite of methods available on a 
		 * SKOS service implementation.
		 * 
		 * @param args
		 * @throws Exception
		 */
		
				public static void main(String [] args) throws Exception
			{
     			System.out.println("Testing of the skos service is about to commence. A series of available operations will be tested");   
				System.out.println("and results (including the service soap response message) will be displayed. " );
				System.out.println();   
				testing_suite();
			}	
	
		static void testing_suite() {
				service = new SKOSThesaurusServiceLocator();



				try{
							URL url_ = new URL(service_url);
							service.getSKOSThesaurusService(url_);
		
							service.setSKOSThesaurusServiceWSDDServiceName(service_name);
		
							SKOSThesaurusServiceSoapBindingStub stub = new SKOSThesaurusServiceSoapBindingStub(url_,service);

				
							System.out.println("**********************************************************");   	
							System.out.println("Testing 'getConcept' with uri " + sample_uri + " ..........");   

							URI uri_ = new URI();
							uri_.setUri(sample_uri);
							Concept result_conc = stub.getConcept(uri_);
		
							if (result_conc != null) {
							// Now let's check we can dump out the data for that concept
								try{		
									resultsDisplay printout = new resultsDisplay();
									msgctxt = service.getCall().getMessageContext();
									printout.result_to_screen(result_conc,msgctxt);
								} catch (Exception e) {
									System.out.println(e);
								}
			
							} else {
							System.out.println("Null result");
							}
							System.out.println("**********************************************************");   	
	
							System.out.println("Testing 'getConcept' with preferred label " + sample_pref_label_ + " ..........");  
			
									URI thes_uri_ = new URI();
									thes_uri_.setUri(sample_thes_uri);
									stub.setTimeout(3000000);
									Concept result = null;
									try {
										result = stub.getConceptByPreferredLabel(sample_pref_label_, thes_uri_);
									} catch (Exception e)
									{
										System.out.println(e);
									}	
									if (result != null) {
											// Now let's check we can dump out the data for that concept
											try{		
															resultsDisplay printout = new resultsDisplay();
															msgctxt = service.getCall().getMessageContext();
															printout.result_to_screen(result,msgctxt);
											} catch (Exception e) {
											System.out.println(e);
									}

									} else {
												System.out.println("Null result");
									}
				
							System.out.println("**********************************************************");   	
							System.out.println("Testing 'getConcept' with externalID " + sample_extid + " ..........");  
				
							Concept result_ = stub.getConceptByExternalID(sample_extid, thes_uri_);
			
							if (result_ != null) {
								// Now let's check we can dump out the data for that concept
									try{		
										resultsDisplay printout = new resultsDisplay();
										msgctxt = service.getCall().getMessageContext();
										printout.result_to_screen(result_,msgctxt);
									} catch (Exception e) {
										System.out.println(e);
									}

							} else {
							System.out.println("Null result");
							}
				
							System.out.println("**********************************************************");   	
				
					System.out.println("Testing 'getConceptRelatives' with  a concept and a relation: " + sample_uri + ", "  + sample_relation);  
					Concept dummy_concept = new Concept();
					dummy_concept.setUri(uri_);				
					Relation reln = new Relation();
					reln.setLabel(sample_relation);
					Concept[] results_ = stub.getConceptRelatives(dummy_concept, reln);
			
					if (results_ != null) {
						// Now let's check we can dump out the data for that concept
							try{		
								resultsDisplay printout = new resultsDisplay();
								msgctxt = service.getCall().getMessageContext();
								printout.results_to_screen(results_,msgctxt);
							} catch (Exception e) {
								System.out.println(e);
							}

					} else {
					System.out.println("Null result");
					}
				
					System.out.println("**********************************************************");   	

				
					System.out.println("Testing 'getSupportedSemanticRelationsByThesaurus with thesaurus uri:  " +  sample_thes_uri);  
					Relation[] result_relns = stub.getSupportedSemanticRelationsByThesaurus(thes_uri_);
			
					if (result_relns != null) {
						// Now let's check we can dump out the data for that concept
							try{		
								resultsDisplay printout = new resultsDisplay();
								msgctxt = service.getCall().getMessageContext();
								printout.results_to_screen(result_relns,msgctxt);
							} catch (Exception e) {
								System.out.println(e);
							}

					} else {
					System.out.println("Null result");
					}
				
					System.out.println("**********************************************************");   	

				
					System.out.println("Testing 'getSupportedSemanticRelations");  
					Relation[] result_relns_ = stub.getSupportedSemanticRelations();
			
					if (result_relns_ != null) {
						// Now let's check we can dump out the data for that concept
							try{		
								resultsDisplay printout = new resultsDisplay();
								msgctxt = service.getCall().getMessageContext();
								printout.results_to_screen(result_relns_,msgctxt);
							} catch (Exception e) {
								System.out.println(e);
							}

					} else {
					System.out.println("Null result");
					}
				


					System.out.println("**********************************************************");   	
				
										System.out.println("Testing 'getConceptRelatives' with  a concept and a relation & a thesaurus uri: " + sample_uri + ", "  + sample_relation + ", " + sample_thes_uri );  
										Concept[] result_concepts = stub.getConceptRelativesByThesaurus(dummy_concept, reln,  thes_uri_);
			
										if (result_concepts != null) {
											// Now let's check we can dump out the data for that concept
												try{		
													resultsDisplay printout = new resultsDisplay();
													msgctxt = service.getCall().getMessageContext();
													printout.results_to_screen(result_concepts,msgctxt);
												} catch (Exception e) {
													System.out.println(e);
												}

										} else {
										System.out.println("Null result");
										}


					System.out.println("**********************************************************");   	
				
										System.out.println("Testing 'getConceptRelativesbyPath' with  a concept and and 'broader' relation & path = 3: " + sample_uri + ", "  + sample_relation);

											int tmp_int = 3;
										ConceptRelatives[] result__concepts = stub.getConceptRelativesByPath(dummy_concept, reln, thes_uri_ , tmp_int);			
										if (result__concepts != null) {
											// Now let's check we can dump out the data for that concept
												try{		
													resultsDisplay printout = new resultsDisplay();
													msgctxt = service.getCall().getMessageContext();
													printout.results_to_screen(result__concepts,msgctxt);
												} catch (Exception e) {
													System.out.println(e);
												}

										} else {
										System.out.println("Null result");
										}

					System.out.println("**********************************************************");   	
				
										System.out.println("Testing 'getallConceptRelatives' - i.e. the ones 'nearest' to this concept: " + sample_uri);

										Concept[] relatives = stub.getAllConceptRelatives(dummy_concept);			
										if (relatives != null) {
											// Now let's check we can dump out the data for that concept
												try{		
													resultsDisplay printout = new resultsDisplay();
													msgctxt = service.getCall().getMessageContext();
													printout.results_to_screen(relatives,msgctxt);
												} catch (Exception e) {
													System.out.println(e);
												}

										} else {
										System.out.println("Null result");
										}


/*				
										System.out.println("**********************************************************");   	
		
										System.out.println("Testing 'getConceptsMatchingKeyword' with keyword: " + sample_keyword );  
										Concept[] result_concepts_ = stub.getConceptsMatchingKeyword(sample_keyword);
			
										if (result_concepts_ != null) {
											// Now let's check we can dump out the data for that concept
												try{		
													resultsDisplay printout = new resultsDisplay();
													msgctxt = service.getCall().getMessageContext();
													printout.results_to_screen(result_concepts_,msgctxt);
												} catch (Exception e) {
													System.out.println(e);
												}

										} else {
										System.out.println("Null result");
										}
				
										System.out.println("**********************************************************");   							

					System.out.println("Testing 'getConceptsMatchingKeywordbyThesaurus' with keyword: " + sample_keyword + " and thesaurus: " +  sample_thes_uri);  
					stub.setTimeout(36000000);
					Concept[] res_concepts_ = stub.getConceptsMatchingKeywordByThesaurus(sample_keyword,  thes_uri_);
			
					if (res_concepts_ != null) {
						// Now let's check we can dump out the data for that concept
							try{		
								resultsDisplay printout = new resultsDisplay();
								msgctxt = service.getCall().getMessageContext();
								printout.results_to_screen(res_concepts_,msgctxt);
							} catch (Exception e) {
								System.out.println(e);
							}

					} else {
					System.out.println("Null result");
					}
				
					System.out.println("**********************************************************");   							

*/
						
				
				
				System.out.println("Testing Process now complete");
					
				
				}   catch (Exception e){
					logger.error(e);   

				
				} // end try

				} // end testing suite


} // end class
		
			
