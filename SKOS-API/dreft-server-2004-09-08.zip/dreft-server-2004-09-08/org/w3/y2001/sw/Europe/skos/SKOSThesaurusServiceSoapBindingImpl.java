/**
 * SKOSThesaurusServiceSoapBindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter
 * but is now edited to invoke the demonstration services methods.
 * 
 * TODO: Merge with DemoService
 */

/**
 *
 * SKOS API invoking the DemoService implementation classes.
 *
 *
 * @author Nikki Rogers, Dave Beckett
 *
 */

package org.w3.y2001.sw.Europe.skos;

public class SKOSThesaurusServiceSoapBindingImpl implements SKOSThesaurus{

    public Concept getConcept(URI in0) throws java.rmi.RemoteException {
        DemoService demoserv = new DemoService();
        return demoserv.getConcept(in0); 
    }

 
    public Concept[] getConceptsMatchingRegex(String in0) throws java.rmi.RemoteException {
      // TODO
      return null;
    }
  
    public Relation[] getSupportedSemanticRelations() throws java.rmi.RemoteException {
      DemoService demoserv = new DemoService();
      return demoserv.getSupportedSemanticRelations();
    }
  
    public Concept[] getConceptRelatives(Concept in0, Relation in1) throws java.rmi.RemoteException {
      DemoService demoserv = new DemoService();
      return demoserv.getConceptRelatives(in0,in1); 
    }
  
    public Concept[] getAllConceptRelatives(Concept in0) throws java.rmi.RemoteException {
		DemoService demoserv = new DemoService();
		return demoserv.getAllConceptRelatives(in0); 
	}

    public Concept[] getTopmostConcepts(URI in0) throws java.rmi.RemoteException {
      DemoService demoserv = new DemoService();
      return demoserv.getTopmostConcepts(in0);
    }

    public Concept[] getTopConcepts(Concept in0, URI in1) throws java.rmi.RemoteException {
      DemoService demoserv = new DemoService();
      return demoserv.getTopConcepts(in0, in1);
    }

    public Concept getConceptByPreferredLabel(String in0, URI in1) throws java.rmi.RemoteException {
      DemoService demoserv = new DemoService();
      return demoserv.getConceptByPreferredLabel(in0,in1);
    }

    public Concept getConceptByExternalID(String in0, URI in1) throws java.rmi.RemoteException {
      DemoService demoserv = new DemoService();
      return demoserv. getConceptByExternalID(in0, in1);
    }

    public Concept[] getConceptsMatchingKeywordByThesaurus(String in0, URI in1) throws java.rmi.RemoteException {
      DemoService demoserv = new DemoService();
      return demoserv.getConceptsMatchingKeywordByThesaurus(in0, in1);
    }

	public Concept[] getConceptsMatchingKeyword(String in0) throws java.rmi.RemoteException {
	   DemoService demoserv = new DemoService();
	   return demoserv.getConceptsMatchingKeyword(in0);
	 }

    public Concept[] getConceptsMatchingRegexByThesaurus(String in0, URI in1) throws java.rmi.RemoteException {
      // TODO
      return null;
    }

    public Relation[] getSupportedSemanticRelationsByThesaurus(URI in0) throws java.rmi.RemoteException {
      DemoService demoserv = new DemoService();
      return demoserv.getSupportedSemanticRelationsByThesaurus(in0);
    }

    public Concept[] getConceptRelativesByThesaurus(Concept in0, Relation in1, URI in2) throws java.rmi.RemoteException {
      DemoService demoserv = new DemoService();
      return demoserv.getConceptRelativesByThesaurus(in0, in1, in2);
    }

    public Concept[] getAllConceptRelativesByThesaurus(Concept in0, URI in1) throws java.rmi.RemoteException {
  		DemoService demoserv = new DemoService();
		return demoserv.getAllConceptRelativesByThesaurus(in0, in1);
     }

    public ConceptRelatives[] getConceptRelativesByPath(Concept in0, Relation in1, URI in2, int in3) throws java.rmi.RemoteException {
		DemoService demoserv = new DemoService();
		return demoserv.getConceptRelativesByPath(in0,in1,in2, in3);
  
    }

    public ConceptRelatives[] getAllConceptsByPath(Concept in0, Relation in1, int in2) throws java.rmi.RemoteException {
      // TODO
      return null;
    }

}
