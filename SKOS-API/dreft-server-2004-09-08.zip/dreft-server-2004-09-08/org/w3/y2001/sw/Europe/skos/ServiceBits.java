/** SKOS Thesaurus API - bits and pieces
 *
 * @author Dave Beckett, Nikki Rogers, Alistair Miles.
 * @version $Id: ServiceBits.java,v 1.3 2004/04/06 14:49:58 cmdjb Exp $ .
 *
 */

package org.w3.y2001.sw.Europe.skos;

/**
 * This is a temporary file storing fragments of API that will
 * eventually move into the Service class.  Everything here is
 * unstable.
 *
 */

public interface ServiceBits {


  /** Return a list of all supported semantic mappings along with definitions
   */
  public Relation[] getSupportedSemanticMappings();

  /** Return a list of all supported semantic mappings along with definitions for a pair of thesauri
   * @param sourceThesaurus The source thesaurus in a mapping.
   * @param targetThesaurus The target thesaurus in a mapping.
   */
  public Relation[] getSupportedSemanticMappingsByThesauri(URI sourceThesaurus, URI targetThesaurus);


  /** Return a list of all mappings from the source concept to the target
   * thesaurus, according to the given semantic mapping relation.
   * @param concept The concept.
   * @param relation The semantic mapping property.
   * @param targetThesaurus The target thesaurus in a mapping.
   */
  public Mapping[] getConceptMappings(Concept concept, Relation relation, URI targetThesaurus);

  /** Return a list of all mappings from the concept identified by preferred label to the target
   * thesaurus, according to the given semantic mapping relation.
   * @param prefLabel The prefered label of the concept.
   * @param relation The semantic mapping relation.
   * @param targetThesaurus The target thesaurus in a mapping.
   */
  public Mapping[] getConceptMappingsByLabel(String prefLabel, String sourceThesaurus, Relation relation, URI targetThesaurus);


  /** Return a list of all mappings from the source concept to the target thesaurus by any semantic mapping relation
   * @param concept The concept.
   * @param targetThesaurus The target thesaurus in a mapping.
   */
  public Mapping[] getAllConceptMappings(Concept concept, URI targetThesaurus);

  /** Return a list of all mappings from the source identified by preferred label to the target thesaurus by any semantic mapping relation
   * @param prefLabel The prefered label.
   * @param sourceThesaurus The target thesaurus in a mapping.
   * @param targetThesaurus The target thesaurus in a mapping.
   */
  public Mapping[] getAllConceptMappingsByLabel(String prefLabel, URI sourceThesaurus, URI targetThesaurus);


  /** Return the result of an RDF query on the graph
   * @param modelReference URI of the graph model.
   * @param query The query string.
   * @param queryLanguage The URI identifying the query language.
   *
   * STATUS: experimental
   *
   * Intended to be similar to the RDF Net API
   * http://www.w3.org/Submission/2003/SUBM-rdf-netapi-20031002/
   * Query operation with the result format only allowing bindings
   */
  public Binding[] RDFquery(String modelReference, String query, URI queryLanguage);


  /** Turn a concept into a syntax format
   * @param concept The concept.
   * @param syntaxFormat The URI of the syntax format.
   *
   * STATUS: experimental method
   *
   * This allows the return format of the method to give
   * results in for example, SKOS-RDF/XML-ABBREV, SKOS-RDF/N3, ZThes
   * XML, XTM, etc..
   */
  public String getConceptAsSyntax(Concept concept, String syntaxFormat);
  
}
