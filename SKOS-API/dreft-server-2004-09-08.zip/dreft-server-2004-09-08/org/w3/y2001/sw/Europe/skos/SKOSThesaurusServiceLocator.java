/**
 * SKOSThesaurusServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package org.w3.y2001.sw.Europe.skos;

public class SKOSThesaurusServiceLocator extends org.apache.axis.client.Service implements org.w3.y2001.sw.Europe.skos.SKOSThesaurusService {

    // Use to get a proxy class for SKOSThesaurusService
    private final java.lang.String SKOSThesaurusService_address = "http://thes.ilrt.bris.ac.uk/SKOSThesaurusService";

    public java.lang.String getSKOSThesaurusServiceAddress() {
        return SKOSThesaurusService_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String SKOSThesaurusServiceWSDDServiceName = "SKOSThesaurusService";

    public java.lang.String getSKOSThesaurusServiceWSDDServiceName() {
        return SKOSThesaurusServiceWSDDServiceName;
    }

    public void setSKOSThesaurusServiceWSDDServiceName(java.lang.String name) {
        SKOSThesaurusServiceWSDDServiceName = name;
    }

    public org.w3.y2001.sw.Europe.skos.SKOSThesaurus getSKOSThesaurusService() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(SKOSThesaurusService_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getSKOSThesaurusService(endpoint);
    }

    public org.w3.y2001.sw.Europe.skos.SKOSThesaurus getSKOSThesaurusService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            org.w3.y2001.sw.Europe.skos.SKOSThesaurusServiceSoapBindingStub _stub = new org.w3.y2001.sw.Europe.skos.SKOSThesaurusServiceSoapBindingStub(portAddress, this);
            _stub.setPortName(getSKOSThesaurusServiceWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (org.w3.y2001.sw.Europe.skos.SKOSThesaurus.class.isAssignableFrom(serviceEndpointInterface)) {
                org.w3.y2001.sw.Europe.skos.SKOSThesaurusServiceSoapBindingStub _stub = new org.w3.y2001.sw.Europe.skos.SKOSThesaurusServiceSoapBindingStub(new java.net.URL(SKOSThesaurusService_address), this);
                _stub.setPortName(getSKOSThesaurusServiceWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        String inputPortName = portName.getLocalPart();
        if ("SKOSThesaurusService".equals(inputPortName)) {
            return getSKOSThesaurusService();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "SKOSThesaurusService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("SKOSThesaurusService"));
        }
        return ports.iterator();
    }

}
