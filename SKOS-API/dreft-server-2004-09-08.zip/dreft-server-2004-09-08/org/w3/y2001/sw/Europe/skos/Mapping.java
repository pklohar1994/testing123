/** SKOS Mapping
 *
 * @author Dave Beckett, Nikki Rogers, Alistair Miles.
 * @version $Id: Mapping.java,v 1.8 2004/04/29 10:38:22 cmdjb Exp $ .
 *
 */

package org.w3.y2001.sw.Europe.skos;

/**
 * A class for a SKOS semantic mapping between two concepts
 *
 * The SKOS-Mapping draft deliverable is at
 *   <a href="http://www.w3c.rl.ac.uk/SWAD/deliverables/8.4.html">http://www.w3c.rl.ac.uk/SWAD/deliverables/8.4.html</a>
 * and the draft vocabulary at
 *   <a href="http://www.w3c.rl.ac.uk/2003/11/21-skos-mapping">http://www.w3c.rl.ac.uk/2003/11/21-skos-mapping</a>
 * Which lists the defined mapping properties.
 */

public class Mapping 
{
  public Concept source;
  public URI sourceThesaurus;
  
  public Concept target;
  public URI targetThesaurus;

  public String relation;
}
