/**
 * SKOSThesaurusServiceSoapBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package org.w3.y2001.sw.Europe.skos;

public class SKOSThesaurusServiceSoapBindingStub extends org.apache.axis.client.Stub implements org.w3.y2001.sw.Europe.skos.SKOSThesaurus {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[17];
        org.apache.axis.description.OperationDesc oper;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getConcept");
        oper.addParameter(new javax.xml.namespace.QName("", "in0"), new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "URI"), org.w3.y2001.sw.Europe.skos.URI.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Concept"));
        oper.setReturnClass(org.w3.y2001.sw.Europe.skos.Concept.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getConceptReturn"));
        oper.setStyle(org.apache.axis.enum.Style.RPC);
        oper.setUse(org.apache.axis.enum.Use.ENCODED);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getConceptsMatchingKeyword");
        oper.addParameter(new javax.xml.namespace.QName("", "in0"), new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_Concept"));
        oper.setReturnClass(org.w3.y2001.sw.Europe.skos.Concept[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getConceptsMatchingKeywordReturn"));
        oper.setStyle(org.apache.axis.enum.Style.RPC);
        oper.setUse(org.apache.axis.enum.Use.ENCODED);
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getConceptsMatchingRegex");
        oper.addParameter(new javax.xml.namespace.QName("", "in0"), new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_Concept"));
        oper.setReturnClass(org.w3.y2001.sw.Europe.skos.Concept[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getConceptsMatchingRegexReturn"));
        oper.setStyle(org.apache.axis.enum.Style.RPC);
        oper.setUse(org.apache.axis.enum.Use.ENCODED);
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getSupportedSemanticRelations");
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_Relation"));
        oper.setReturnClass(org.w3.y2001.sw.Europe.skos.Relation[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getSupportedSemanticRelationsReturn"));
        oper.setStyle(org.apache.axis.enum.Style.RPC);
        oper.setUse(org.apache.axis.enum.Use.ENCODED);
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getConceptRelatives");
        oper.addParameter(new javax.xml.namespace.QName("", "in0"), new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Concept"), org.w3.y2001.sw.Europe.skos.Concept.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.addParameter(new javax.xml.namespace.QName("", "in1"), new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Relation"), org.w3.y2001.sw.Europe.skos.Relation.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_Concept"));
        oper.setReturnClass(org.w3.y2001.sw.Europe.skos.Concept[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getConceptRelativesReturn"));
        oper.setStyle(org.apache.axis.enum.Style.RPC);
        oper.setUse(org.apache.axis.enum.Use.ENCODED);
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getAllConceptRelatives");
        oper.addParameter(new javax.xml.namespace.QName("", "in0"), new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Concept"), org.w3.y2001.sw.Europe.skos.Concept.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_Concept"));
        oper.setReturnClass(org.w3.y2001.sw.Europe.skos.Concept[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getAllConceptRelativesReturn"));
        oper.setStyle(org.apache.axis.enum.Style.RPC);
        oper.setUse(org.apache.axis.enum.Use.ENCODED);
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getTopmostConcepts");
        oper.addParameter(new javax.xml.namespace.QName("", "in0"), new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "URI"), org.w3.y2001.sw.Europe.skos.URI.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_Concept"));
        oper.setReturnClass(org.w3.y2001.sw.Europe.skos.Concept[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getTopmostConceptsReturn"));
        oper.setStyle(org.apache.axis.enum.Style.RPC);
        oper.setUse(org.apache.axis.enum.Use.ENCODED);
        _operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getTopConcepts");
        oper.addParameter(new javax.xml.namespace.QName("", "in0"), new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Concept"), org.w3.y2001.sw.Europe.skos.Concept.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.addParameter(new javax.xml.namespace.QName("", "in1"), new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "URI"), org.w3.y2001.sw.Europe.skos.URI.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_Concept"));
        oper.setReturnClass(org.w3.y2001.sw.Europe.skos.Concept[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getTopConceptsReturn"));
        oper.setStyle(org.apache.axis.enum.Style.RPC);
        oper.setUse(org.apache.axis.enum.Use.ENCODED);
        _operations[7] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getConceptByPreferredLabel");
        oper.addParameter(new javax.xml.namespace.QName("", "in0"), new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.addParameter(new javax.xml.namespace.QName("", "in1"), new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "URI"), org.w3.y2001.sw.Europe.skos.URI.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Concept"));
        oper.setReturnClass(org.w3.y2001.sw.Europe.skos.Concept.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getConceptByPreferredLabelReturn"));
        oper.setStyle(org.apache.axis.enum.Style.RPC);
        oper.setUse(org.apache.axis.enum.Use.ENCODED);
        _operations[8] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getConceptByExternalID");
        oper.addParameter(new javax.xml.namespace.QName("", "in0"), new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.addParameter(new javax.xml.namespace.QName("", "in1"), new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "URI"), org.w3.y2001.sw.Europe.skos.URI.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Concept"));
        oper.setReturnClass(org.w3.y2001.sw.Europe.skos.Concept.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getConceptByExternalIDReturn"));
        oper.setStyle(org.apache.axis.enum.Style.RPC);
        oper.setUse(org.apache.axis.enum.Use.ENCODED);
        _operations[9] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getConceptsMatchingKeywordByThesaurus");
        oper.addParameter(new javax.xml.namespace.QName("", "in0"), new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.addParameter(new javax.xml.namespace.QName("", "in1"), new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "URI"), org.w3.y2001.sw.Europe.skos.URI.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_Concept"));
        oper.setReturnClass(org.w3.y2001.sw.Europe.skos.Concept[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getConceptsMatchingKeywordByThesaurusReturn"));
        oper.setStyle(org.apache.axis.enum.Style.RPC);
        oper.setUse(org.apache.axis.enum.Use.ENCODED);
        _operations[10] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getConceptsMatchingRegexByThesaurus");
        oper.addParameter(new javax.xml.namespace.QName("", "in0"), new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.addParameter(new javax.xml.namespace.QName("", "in1"), new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "URI"), org.w3.y2001.sw.Europe.skos.URI.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_Concept"));
        oper.setReturnClass(org.w3.y2001.sw.Europe.skos.Concept[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getConceptsMatchingRegexByThesaurusReturn"));
        oper.setStyle(org.apache.axis.enum.Style.RPC);
        oper.setUse(org.apache.axis.enum.Use.ENCODED);
        _operations[11] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getSupportedSemanticRelationsByThesaurus");
        oper.addParameter(new javax.xml.namespace.QName("", "in0"), new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "URI"), org.w3.y2001.sw.Europe.skos.URI.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_Relation"));
        oper.setReturnClass(org.w3.y2001.sw.Europe.skos.Relation[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getSupportedSemanticRelationsByThesaurusReturn"));
        oper.setStyle(org.apache.axis.enum.Style.RPC);
        oper.setUse(org.apache.axis.enum.Use.ENCODED);
        _operations[12] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getConceptRelativesByThesaurus");
        oper.addParameter(new javax.xml.namespace.QName("", "in0"), new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Concept"), org.w3.y2001.sw.Europe.skos.Concept.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.addParameter(new javax.xml.namespace.QName("", "in1"), new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Relation"), org.w3.y2001.sw.Europe.skos.Relation.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.addParameter(new javax.xml.namespace.QName("", "in2"), new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "URI"), org.w3.y2001.sw.Europe.skos.URI.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_Concept"));
        oper.setReturnClass(org.w3.y2001.sw.Europe.skos.Concept[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getConceptRelativesByThesaurusReturn"));
        oper.setStyle(org.apache.axis.enum.Style.RPC);
        oper.setUse(org.apache.axis.enum.Use.ENCODED);
        _operations[13] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getAllConceptRelativesByThesaurus");
        oper.addParameter(new javax.xml.namespace.QName("", "in0"), new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Concept"), org.w3.y2001.sw.Europe.skos.Concept.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.addParameter(new javax.xml.namespace.QName("", "in1"), new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "URI"), org.w3.y2001.sw.Europe.skos.URI.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_Concept"));
        oper.setReturnClass(org.w3.y2001.sw.Europe.skos.Concept[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getAllConceptRelativesByThesaurusReturn"));
        oper.setStyle(org.apache.axis.enum.Style.RPC);
        oper.setUse(org.apache.axis.enum.Use.ENCODED);
        _operations[14] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getConceptRelativesByPath");
        oper.addParameter(new javax.xml.namespace.QName("", "in0"), new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Concept"), org.w3.y2001.sw.Europe.skos.Concept.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.addParameter(new javax.xml.namespace.QName("", "in1"), new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Relation"), org.w3.y2001.sw.Europe.skos.Relation.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.addParameter(new javax.xml.namespace.QName("", "in2"), new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "URI"), org.w3.y2001.sw.Europe.skos.URI.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.addParameter(new javax.xml.namespace.QName("", "in3"), new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_ConceptRelatives"));
        oper.setReturnClass(org.w3.y2001.sw.Europe.skos.ConceptRelatives[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getConceptRelativesByPathReturn"));
        oper.setStyle(org.apache.axis.enum.Style.RPC);
        oper.setUse(org.apache.axis.enum.Use.ENCODED);
        _operations[15] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getAllConceptsByPath");
        oper.addParameter(new javax.xml.namespace.QName("", "in0"), new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Concept"), org.w3.y2001.sw.Europe.skos.Concept.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.addParameter(new javax.xml.namespace.QName("", "in1"), new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Relation"), org.w3.y2001.sw.Europe.skos.Relation.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.addParameter(new javax.xml.namespace.QName("", "in2"), new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_ConceptRelatives"));
        oper.setReturnClass(org.w3.y2001.sw.Europe.skos.ConceptRelatives[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getAllConceptsByPathReturn"));
        oper.setStyle(org.apache.axis.enum.Style.RPC);
        oper.setUse(org.apache.axis.enum.Use.ENCODED);
        _operations[16] = oper;

    }

    public SKOSThesaurusServiceSoapBindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public SKOSThesaurusServiceSoapBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public SKOSThesaurusServiceSoapBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "URI");
            cachedSerQNames.add(qName);
            cls = org.w3.y2001.sw.Europe.skos.URI.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "ConceptRelatives");
            cachedSerQNames.add(qName);
            cls = org.w3.y2001.sw.Europe.skos.ConceptRelatives.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_Relation");
            cachedSerQNames.add(qName);
            cls = org.w3.y2001.sw.Europe.skos.Relation[].class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(arraysf);
            cachedDeserFactories.add(arraydf);

            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Concept");
            cachedSerQNames.add(qName);
            cls = org.w3.y2001.sw.Europe.skos.Concept.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Relation");
            cachedSerQNames.add(qName);
            cls = org.w3.y2001.sw.Europe.skos.Relation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_Concept");
            cachedSerQNames.add(qName);
            cls = org.w3.y2001.sw.Europe.skos.Concept[].class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(arraysf);
            cachedDeserFactories.add(arraydf);

            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "ArrayOf_tns1_ConceptRelatives");
            cachedSerQNames.add(qName);
            cls = org.w3.y2001.sw.Europe.skos.ConceptRelatives[].class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(arraysf);
            cachedDeserFactories.add(arraydf);

    }

    private org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call =
                    (org.apache.axis.client.Call) super.service.createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
                    _call.setEncodingStyle(org.apache.axis.Constants.URI_SOAP11_ENC);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                        java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                        _call.registerTypeMapping(cls, qName, sf, df, false);
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", t);
        }
    }

    public org.w3.y2001.sw.Europe.skos.Concept getConcept(org.w3.y2001.sw.Europe.skos.URI in0) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getConcept"));

        setRequestHeaders(_call);
        setAttachments(_call);
        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (org.w3.y2001.sw.Europe.skos.Concept) _resp;
            } catch (java.lang.Exception _exception) {
                return (org.w3.y2001.sw.Europe.skos.Concept) org.apache.axis.utils.JavaUtils.convert(_resp, org.w3.y2001.sw.Europe.skos.Concept.class);
            }
        }
    }

    public org.w3.y2001.sw.Europe.skos.Concept[] getConceptsMatchingKeyword(java.lang.String in0) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getConceptsMatchingKeyword"));

        setRequestHeaders(_call);
        setAttachments(_call);
        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (org.w3.y2001.sw.Europe.skos.Concept[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (org.w3.y2001.sw.Europe.skos.Concept[]) org.apache.axis.utils.JavaUtils.convert(_resp, org.w3.y2001.sw.Europe.skos.Concept[].class);
            }
        }
    }

    public org.w3.y2001.sw.Europe.skos.Concept[] getConceptsMatchingRegex(java.lang.String in0) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getConceptsMatchingRegex"));

        setRequestHeaders(_call);
        setAttachments(_call);
        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (org.w3.y2001.sw.Europe.skos.Concept[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (org.w3.y2001.sw.Europe.skos.Concept[]) org.apache.axis.utils.JavaUtils.convert(_resp, org.w3.y2001.sw.Europe.skos.Concept[].class);
            }
        }
    }

    public org.w3.y2001.sw.Europe.skos.Relation[] getSupportedSemanticRelations() throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getSupportedSemanticRelations"));

        setRequestHeaders(_call);
        setAttachments(_call);
        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (org.w3.y2001.sw.Europe.skos.Relation[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (org.w3.y2001.sw.Europe.skos.Relation[]) org.apache.axis.utils.JavaUtils.convert(_resp, org.w3.y2001.sw.Europe.skos.Relation[].class);
            }
        }
    }

    public org.w3.y2001.sw.Europe.skos.Concept[] getConceptRelatives(org.w3.y2001.sw.Europe.skos.Concept in0, org.w3.y2001.sw.Europe.skos.Relation in1) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getConceptRelatives"));

        setRequestHeaders(_call);
        setAttachments(_call);
        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0, in1});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (org.w3.y2001.sw.Europe.skos.Concept[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (org.w3.y2001.sw.Europe.skos.Concept[]) org.apache.axis.utils.JavaUtils.convert(_resp, org.w3.y2001.sw.Europe.skos.Concept[].class);
            }
        }
    }

    public org.w3.y2001.sw.Europe.skos.Concept[] getAllConceptRelatives(org.w3.y2001.sw.Europe.skos.Concept in0) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getAllConceptRelatives"));

        setRequestHeaders(_call);
        setAttachments(_call);
        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (org.w3.y2001.sw.Europe.skos.Concept[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (org.w3.y2001.sw.Europe.skos.Concept[]) org.apache.axis.utils.JavaUtils.convert(_resp, org.w3.y2001.sw.Europe.skos.Concept[].class);
            }
        }
    }

    public org.w3.y2001.sw.Europe.skos.Concept[] getTopmostConcepts(org.w3.y2001.sw.Europe.skos.URI in0) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getTopmostConcepts"));

        setRequestHeaders(_call);
        setAttachments(_call);
        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (org.w3.y2001.sw.Europe.skos.Concept[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (org.w3.y2001.sw.Europe.skos.Concept[]) org.apache.axis.utils.JavaUtils.convert(_resp, org.w3.y2001.sw.Europe.skos.Concept[].class);
            }
        }
    }

    public org.w3.y2001.sw.Europe.skos.Concept[] getTopConcepts(org.w3.y2001.sw.Europe.skos.Concept in0, org.w3.y2001.sw.Europe.skos.URI in1) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[7]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getTopConcepts"));

        setRequestHeaders(_call);
        setAttachments(_call);
        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0, in1});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (org.w3.y2001.sw.Europe.skos.Concept[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (org.w3.y2001.sw.Europe.skos.Concept[]) org.apache.axis.utils.JavaUtils.convert(_resp, org.w3.y2001.sw.Europe.skos.Concept[].class);
            }
        }
    }

    public org.w3.y2001.sw.Europe.skos.Concept getConceptByPreferredLabel(java.lang.String in0, org.w3.y2001.sw.Europe.skos.URI in1) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[8]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getConceptByPreferredLabel"));

        setRequestHeaders(_call);
        setAttachments(_call);
        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0, in1});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (org.w3.y2001.sw.Europe.skos.Concept) _resp;
            } catch (java.lang.Exception _exception) {
                return (org.w3.y2001.sw.Europe.skos.Concept) org.apache.axis.utils.JavaUtils.convert(_resp, org.w3.y2001.sw.Europe.skos.Concept.class);
            }
        }
    }

    public org.w3.y2001.sw.Europe.skos.Concept getConceptByExternalID(java.lang.String in0, org.w3.y2001.sw.Europe.skos.URI in1) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[9]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getConceptByExternalID"));

        setRequestHeaders(_call);
        setAttachments(_call);
        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0, in1});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (org.w3.y2001.sw.Europe.skos.Concept) _resp;
            } catch (java.lang.Exception _exception) {
                return (org.w3.y2001.sw.Europe.skos.Concept) org.apache.axis.utils.JavaUtils.convert(_resp, org.w3.y2001.sw.Europe.skos.Concept.class);
            }
        }
    }

    public org.w3.y2001.sw.Europe.skos.Concept[] getConceptsMatchingKeywordByThesaurus(java.lang.String in0, org.w3.y2001.sw.Europe.skos.URI in1) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[10]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getConceptsMatchingKeywordByThesaurus"));

        setRequestHeaders(_call);
        setAttachments(_call);
        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0, in1});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (org.w3.y2001.sw.Europe.skos.Concept[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (org.w3.y2001.sw.Europe.skos.Concept[]) org.apache.axis.utils.JavaUtils.convert(_resp, org.w3.y2001.sw.Europe.skos.Concept[].class);
            }
        }
    }

    public org.w3.y2001.sw.Europe.skos.Concept[] getConceptsMatchingRegexByThesaurus(java.lang.String in0, org.w3.y2001.sw.Europe.skos.URI in1) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[11]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getConceptsMatchingRegexByThesaurus"));

        setRequestHeaders(_call);
        setAttachments(_call);
        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0, in1});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (org.w3.y2001.sw.Europe.skos.Concept[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (org.w3.y2001.sw.Europe.skos.Concept[]) org.apache.axis.utils.JavaUtils.convert(_resp, org.w3.y2001.sw.Europe.skos.Concept[].class);
            }
        }
    }

    public org.w3.y2001.sw.Europe.skos.Relation[] getSupportedSemanticRelationsByThesaurus(org.w3.y2001.sw.Europe.skos.URI in0) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[12]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getSupportedSemanticRelationsByThesaurus"));

        setRequestHeaders(_call);
        setAttachments(_call);
        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (org.w3.y2001.sw.Europe.skos.Relation[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (org.w3.y2001.sw.Europe.skos.Relation[]) org.apache.axis.utils.JavaUtils.convert(_resp, org.w3.y2001.sw.Europe.skos.Relation[].class);
            }
        }
    }

    public org.w3.y2001.sw.Europe.skos.Concept[] getConceptRelativesByThesaurus(org.w3.y2001.sw.Europe.skos.Concept in0, org.w3.y2001.sw.Europe.skos.Relation in1, org.w3.y2001.sw.Europe.skos.URI in2) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[13]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getConceptRelativesByThesaurus"));

        setRequestHeaders(_call);
        setAttachments(_call);
        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0, in1, in2});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (org.w3.y2001.sw.Europe.skos.Concept[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (org.w3.y2001.sw.Europe.skos.Concept[]) org.apache.axis.utils.JavaUtils.convert(_resp, org.w3.y2001.sw.Europe.skos.Concept[].class);
            }
        }
    }

    public org.w3.y2001.sw.Europe.skos.Concept[] getAllConceptRelativesByThesaurus(org.w3.y2001.sw.Europe.skos.Concept in0, org.w3.y2001.sw.Europe.skos.URI in1) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[14]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getAllConceptRelativesByThesaurus"));

        setRequestHeaders(_call);
        setAttachments(_call);
        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0, in1});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (org.w3.y2001.sw.Europe.skos.Concept[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (org.w3.y2001.sw.Europe.skos.Concept[]) org.apache.axis.utils.JavaUtils.convert(_resp, org.w3.y2001.sw.Europe.skos.Concept[].class);
            }
        }
    }

    public org.w3.y2001.sw.Europe.skos.ConceptRelatives[] getConceptRelativesByPath(org.w3.y2001.sw.Europe.skos.Concept in0, org.w3.y2001.sw.Europe.skos.Relation in1, org.w3.y2001.sw.Europe.skos.URI in2, int in3) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[15]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getConceptRelativesByPath"));

        setRequestHeaders(_call);
        setAttachments(_call);
        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0, in1, in2, new java.lang.Integer(in3)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (org.w3.y2001.sw.Europe.skos.ConceptRelatives[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (org.w3.y2001.sw.Europe.skos.ConceptRelatives[]) org.apache.axis.utils.JavaUtils.convert(_resp, org.w3.y2001.sw.Europe.skos.ConceptRelatives[].class);
            }
        }
    }

    public org.w3.y2001.sw.Europe.skos.ConceptRelatives[] getAllConceptsByPath(org.w3.y2001.sw.Europe.skos.Concept in0, org.w3.y2001.sw.Europe.skos.Relation in1, int in2) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[16]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/ServiceAPI", "getAllConceptsByPath"));

        setRequestHeaders(_call);
        setAttachments(_call);
        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0, in1, new java.lang.Integer(in2)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (org.w3.y2001.sw.Europe.skos.ConceptRelatives[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (org.w3.y2001.sw.Europe.skos.ConceptRelatives[]) org.apache.axis.utils.JavaUtils.convert(_resp, org.w3.y2001.sw.Europe.skos.ConceptRelatives[].class);
            }
        }
    }

}
