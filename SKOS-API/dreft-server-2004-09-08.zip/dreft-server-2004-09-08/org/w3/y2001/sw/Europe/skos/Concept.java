/**
 * Concept.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package org.w3.y2001.sw.Europe.skos;

public class Concept  implements java.io.Serializable {
    private org.w3.y2001.sw.Europe.skos.URI uri;
    private java.lang.String externalID;
    private java.lang.String preferredLabel;
    private java.lang.String[] nonPreferredLabels;
    private org.w3.y2001.sw.Europe.skos.URI inScheme;
    private java.lang.String scopeNote;
    private java.lang.String definition;
    private java.lang.String example;

    public Concept() {
    }

    public org.w3.y2001.sw.Europe.skos.URI getUri() {
        return uri;
    }

    public void setUri(org.w3.y2001.sw.Europe.skos.URI uri) {
        this.uri = uri;
    }

    public java.lang.String getExternalID() {
        return externalID;
    }

    public void setExternalID(java.lang.String externalID) {
        this.externalID = externalID;
    }

    public java.lang.String getPreferredLabel() {
        return preferredLabel;
    }

    public void setPreferredLabel(java.lang.String preferredLabel) {
        this.preferredLabel = preferredLabel;
    }

    public java.lang.String[] getNonPreferredLabels() {
        return nonPreferredLabels;
    }

    public void setNonPreferredLabels(java.lang.String[] nonPreferredLabels) {
        this.nonPreferredLabels = nonPreferredLabels;
    }

    public java.lang.String getNonPreferredLabels(int i) {
        return nonPreferredLabels[i];
    }

    public void setNonPreferredLabels(int i, java.lang.String value) {
        this.nonPreferredLabels[i] = value;
    }

    public org.w3.y2001.sw.Europe.skos.URI getInScheme() {
        return inScheme;
    }

    public void setInScheme(org.w3.y2001.sw.Europe.skos.URI inScheme) {
        this.inScheme = inScheme;
    }

    public java.lang.String getScopeNote() {
        return scopeNote;
    }

    public void setScopeNote(java.lang.String scopeNote) {
        this.scopeNote = scopeNote;
    }

    public java.lang.String getDefinition() {
        return definition;
    }

    public void setDefinition(java.lang.String definition) {
        this.definition = definition;
    }

    public java.lang.String getExample() {
        return example;
    }

    public void setExample(java.lang.String example) {
        this.example = example;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Concept)) return false;
        Concept other = (Concept) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.uri==null && other.getUri()==null) || 
             (this.uri!=null &&
              this.uri.equals(other.getUri()))) &&
            ((this.externalID==null && other.getExternalID()==null) || 
             (this.externalID!=null &&
              this.externalID.equals(other.getExternalID()))) &&
            ((this.preferredLabel==null && other.getPreferredLabel()==null) || 
             (this.preferredLabel!=null &&
              this.preferredLabel.equals(other.getPreferredLabel()))) &&
            ((this.nonPreferredLabels==null && other.getNonPreferredLabels()==null) || 
             (this.nonPreferredLabels!=null &&
              java.util.Arrays.equals(this.nonPreferredLabels, other.getNonPreferredLabels()))) &&
            ((this.inScheme==null && other.getInScheme()==null) || 
             (this.inScheme!=null &&
              this.inScheme.equals(other.getInScheme()))) &&
            ((this.scopeNote==null && other.getScopeNote()==null) || 
             (this.scopeNote!=null &&
              this.scopeNote.equals(other.getScopeNote()))) &&
            ((this.definition==null && other.getDefinition()==null) || 
             (this.definition!=null &&
              this.definition.equals(other.getDefinition()))) &&
            ((this.example==null && other.getExample()==null) || 
             (this.example!=null &&
              this.example.equals(other.getExample())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getUri() != null) {
            _hashCode += getUri().hashCode();
        }
        if (getExternalID() != null) {
            _hashCode += getExternalID().hashCode();
        }
        if (getPreferredLabel() != null) {
            _hashCode += getPreferredLabel().hashCode();
        }
        if (getNonPreferredLabels() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getNonPreferredLabels());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getNonPreferredLabels(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getInScheme() != null) {
            _hashCode += getInScheme().hashCode();
        }
        if (getScopeNote() != null) {
            _hashCode += getScopeNote().hashCode();
        }
        if (getDefinition() != null) {
            _hashCode += getDefinition().hashCode();
        }
        if (getExample() != null) {
            _hashCode += getExample().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Concept.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Concept"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("uri");
        elemField.setXmlName(new javax.xml.namespace.QName("", "uri"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "URI"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("externalID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "externalID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("preferredLabel");
        elemField.setXmlName(new javax.xml.namespace.QName("", "preferredLabel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nonPreferredLabels");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nonPreferredLabels"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inScheme");
        elemField.setXmlName(new javax.xml.namespace.QName("", "inScheme"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "URI"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("scopeNote");
        elemField.setXmlName(new javax.xml.namespace.QName("", "scopeNote"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("definition");
        elemField.setXmlName(new javax.xml.namespace.QName("", "definition"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("example");
        elemField.setXmlName(new javax.xml.namespace.QName("", "example"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
