package org.w3.y2001.sw.Europe.skos;

import org.apache.log4j.Logger;

import org.w3.y2001.sw.Europe.skos.Relation;
import org.w3.y2001.sw.Europe.skos.URI;
import org.w3.y2001.sw.Europe.skos.query.*;
import org.w3.y2001.sw.Europe.skos.repository.*;
import org.w3.y2001.sw.Europe.skos.results.*;

import java.util.ArrayList;

/** A demo service that implements the Service class (SKOSThesaurus)
 * 
 * An Axis SOAP Service implementation can merely instantiate this
 * class & call on its methods directly.  At the time of releasing this first 
 * draft implementation, this class represents a level of indirection that
 * has been helpful in development, but it should perhaps be merged with 
 * the service class instead.
 *
 * Service methods currently implemented:
 *   getConcept(URI uri)
 *   getConceptByPreferredLabel(String preferredLabel, URI thesaurus) 
 *   getConceptByExternalID(String externalID, URI thesaurus) 
 *   getConceptRelatives(Concept concept, Relation relation)  
 *   getConceptRelativesByThesaurus(Concept conc_, Relation rln, URI uri_) 
 *   getConceptsMatchingKeyword(String key_word) 
 *   getConceptsMatchingKeywordByThesaurus(String key_word, URI thes_uri) 
 *   getSupportedSemanticRelationsByThesaurus(URI thes_uri)
 *   getSupportedSemanticRelations()
 *   getAllConceptRelatives(Concept conc)
 *   getAllConceptRelativesByThesaurus(Concept conc, URI thes_uri)
 *   getConceptRelativesByPath(Concept conc_, Relation rln, URI uri_, int distance) 
 *  (see also the javadoc - e.g. getTopConcept methods are also implemented)
 * 
 * Methods currently NOT implemented:
 *   getConceptsMatchingRegexByThesaurus(String regex, URI thes_uri)
 *   getConceptsMatchingRegex(String regex)
 *  getConceptByInternalID(String in0, URI in1) [obsolete?]
 *   getAllConceptsByPath(Concept conc, Relation reln, int distance)
*
 * @author Nikki Rogers
 * @author Dave Beckett
*/
public class DemoService implements SKOSThesaurus {


	static Logger logger = Logger.getLogger(DemoService.class.getName());
	
	private final String queryClassName="org.w3.y2001.sw.Europe.skos.query.SERQLQuery";
	private final String repoClassName="org.w3.y2001.sw.Europe.skos.repository.SesameRepo";
	// the use of 'mode' is to distinguish whether the context is that of the servlet container
	// or instead whether the API is being accessed direct by another application
	private static RepositoryMode  mode;
	
	
	public DemoService() {
			
		logger.debug(this + "Starting the skos demoservice .... ");     
		mode = RepositoryMode.SERVLET;
	}
		
	/** Constructor which permits direct access to the API, allowing
	 *  external applications to embed the SKOS DemoService within. 
     * @param  access_mode  to indicate whether the context is servlet container or direct API access via another application 
	 */	
	public DemoService(String access_mode) {
			
			logger.debug(this + "Starting the skos demoservice in the " + access_mode  +  " access mode. ");     
			mode = RepositoryMode.DIRECT;			
	}
		
	/** Get a concept via its uri
	 * @param  uri  absolute URI for the Concept
	 */	
	public Concept getConcept(URI uri) {
		
		logger.debug(this + "Calling the getConcept method.");  
		Concept result_concept = null;
		
		try {
			// first create a query object and parse the query.
			// identify which type of query class to load 
			Class query_ = Class.forName(queryClassName);
			AbstractQuery query = (AbstractQuery) query_.newInstance();
			query.parseQuery(uri);

			// identify which type of repository ("repo") class to load
			Class repo_ = Class.forName(repoClassName);
			AbstractRepo repo = (AbstractRepo) repo_.newInstance();
			
			repo.configure(mode);
			// Now let the repo object do the work: it will take care of issuing the query 
			//against the appropriate repository, and parsing the results from the repository
			// into a concept object.                       
			result_concept = repo.doSearch_for_concept(query);
			return result_concept;
				
		} 
		// TODO: decide whether to make this catch blocks into a single error catcher (this
		// decision applies to all the methods in this class
		catch(ClassNotFoundException cnfe)
		{
			logger.error(this + " Unable to create a required repository or query class " + cnfe);  
			return result_concept; 
		}
		catch(IllegalAccessException iae)
		{
			logger.error(this + " Unable to create a required repository or query class " + iae);   
			return result_concept; 
		}
		catch(InstantiationException ie)
		{
			logger.error(this + " Unable to create a required repository or query class " + ie);    
			return result_concept; 
		}
		catch(Exception e) {
			logger.error(this + " Unable to create a required repository or query class " + e);     
			return result_concept; 
		}
			
		
	} // end try
		
	/** Get a concept by its preferred label for a particular thesaurus.
	 * @param  thesaurus  absolute URI for the thesaurus as known to the service
	 * @param  preferredLabel case sensitive label for this Concept (note that this will be used as an exact match - no wildcards)
	 */	
	public Concept getConceptByPreferredLabel(String preferredLabel, URI thesaurus) {
		
		logger.debug(this + "Calling the getConceptByPreferredLabel method.");  
		Concept result_concept = null;
		
		try {
				// first create a query object and parse the query
				// identify which type of query class to load 
					Class query_ = Class.forName(queryClassName);
					AbstractQuery query = (AbstractQuery) query_.newInstance();
					
					query.parseExactQuery(thesaurus, preferredLabel);
					
					//  identify which type of repository ("repo") class to load
					 Class repo_ = Class.forName(repoClassName);
					 AbstractRepo repo = (AbstractRepo) repo_.newInstance();
					repo.configure(mode);
					 // Now let the repo object do the work: it will take care of issuing the query 
					 //against the appropriate repository, and parsing the results from the repository
					 // into a concept object.                                      
					 result_concept = repo.doSearch_for_concept(query);
					 return result_concept;
				
		} 

		catch(ClassNotFoundException cnfe)
		{
		  logger.error(this + " Unable to create a required repository or query class " + cnfe);        
		  return result_concept; 
		}
		
		catch(IllegalAccessException iae)
		{
		  logger.error(this + " Unable to create a required repository or query class " + iae); 
		  return result_concept; 
		}
		catch(InstantiationException ie)
		{
		  logger.error(this + " Unable to create a required repository or query class " + ie);  
		  return result_concept; 
		}
		
		catch(Exception e)
		{
		  logger.error(this + " Unable to create a required repository or query class " + e);   
		  return result_concept; 
		}
			
		
	}       

		
	/** Get a concept by its external ID (this method likely to be deprecated)
	 * @param  thesaurus  absolute URI for the thesaurus as known to the service
	 * @param  externalID an ID assigned to the Concept via an external authority - i.e. likely the original creator of this thesaurus
	 */	
	public Concept getConceptByExternalID(String externalID, URI thesaurus) {
			
			logger.debug(this + "Calling the getConceptbyExternalID method.");      
			Concept result_concept = null;
		
			try {
						// first create a query object and parse the query
			
						// identify which type of query class to load
						Class query_ = Class.forName(queryClassName);
						AbstractQuery query = (AbstractQuery) query_.newInstance();
						query.parseQuery(externalID, thesaurus, "externalID");
						// System.out.println(" got query " + query.getQuery());
						
						//      identify which type of repository ("repo") class to load
						 Class repo_ = Class.forName(repoClassName);
						 AbstractRepo repo = (AbstractRepo) repo_.newInstance();
						repo.configure(mode);
					
			
						//Now let the repo object do the work: it will take care of issuing the query 
						//against the appropriate repository, and parsing the results from the repository
						// into a concept object.
						 result_concept = repo.doSearch_for_concept(query);
						return result_concept;
				
			} 

			catch(ClassNotFoundException cnfe)
			{
			  logger.error(this + " Unable to create a required repository or query class " + cnfe);        
			  return result_concept; 
			}
			
			catch(IllegalAccessException iae)
			{
			  logger.error(this + " Unable to create a required repository or query class " + iae); 
			  return result_concept; 
			}
			catch(InstantiationException ie)
			{
			  logger.error(this + " Unable to create a required repository or query class " + ie);  
			  return result_concept; 
			}
			
			catch(Exception e)
			{
			  
			  logger.error(this + " Unable to create a required repository or query class " + e);   
			  return result_concept; 
			}
			
		
	}       


		
	/** Get an array of concepts via a keyword match
	 * @param  key_word non-case sensitive text 
	 */	
	public Concept[] getConceptsMatchingKeyword(String key_word) {
			
			
		logger.debug(this + "Calling the getConceptsMatchingKeyword method.");          
		Concept[] result_concepts = null;
			   try {
							   // first create a query object and parse the query
							   // identify which type of query class to load 
							   Class query_ = Class.forName(queryClassName);
							   AbstractQuery query = (AbstractQuery) query_.newInstance();
							   query.parseQuery(key_word);
							   
							   // System.out.println(" got query " + query.getQuery());
							   //   identify which type of repository ("repo") class to load
							   Class repo_ = Class.forName(repoClassName);
							   AbstractRepo repo = (AbstractRepo) repo_.newInstance();
								repo.configure(mode);
			
							   // Now let the repo object do the work: it will take care of issuing the query 
							   //against the appropriate repository, and parsing the results from the repository
							   // into an array of concept objects.         
							   result_concepts = repo.doSearch_for_concepts(query);
							   return result_concepts;
				
		   } 

		   catch(ClassNotFoundException cnfe)
		   {
		     logger.error(this + " Unable to create a required repository or query class " + cnfe);     
		     return result_concepts; 
		   }
		   
		   catch(IllegalAccessException iae)
		   {
		     logger.error(this + " Unable to create a required repository or query class " + iae);      
		     return result_concepts; 
		   }
		   catch(InstantiationException ie)
		   {
		     logger.error(this + " Unable to create a required repository or query class " + ie);       
		     return result_concepts; 
		   }
		   
		   catch(Exception e)
		   {
		     
		     logger.error(this + " Unable to create a required repository or query class " + e);        
		     return result_concepts; 
		   }                                    
		   
		   
	}
	
		
	/** Get an array of concepts via a keyword match for a particular thesaurus.
	 * @param  thes_uri  absolute URI for the thesaurus as known to the service
	 * @param  key_word non-case sensitive text 
	 */	
	public Concept[] getConceptsMatchingKeywordByThesaurus(String key_word, URI thes_uri) {
		
		logger.debug(this + "Calling the getConceptsMatchingKeywordByThesaurus method.");                       
		Concept[] result_concepts = null;
	   
		try {
				// first create a query object and parse the query
				// identify which type of query class to load 
				Class query_ = Class.forName(queryClassName);
				AbstractQuery query = (AbstractQuery) query_.newInstance();
				query.parseQuery(key_word, thes_uri);
				
				// System.out.println(" got query " + query.getQuery());
				//      identify which type of repository ("repo") class to load
				Class repo_ = Class.forName(repoClassName);
				AbstractRepo repo = (AbstractRepo) repo_.newInstance();
				repo.configure(mode);
				// Now let the repo object do the work: it will take care of issuing the query 
				//against the appropriate repository, and parsing the results from the repository
				// into an array of concept objects.            
				result_concepts = repo.doSearch_for_concepts(query);
				return result_concepts;
					
	
		} 

		catch(ClassNotFoundException cnfe)
		{
		  logger.error(this + " Unable to create a required repository or query class " + cnfe);        
		  return result_concepts; 
		}
		
		catch(IllegalAccessException iae)
		{
		  logger.error(this + " Unable to create a required repository or query class " + iae); 
		  return result_concepts; 
		}
		catch(InstantiationException ie)
		{
		  logger.error(this + " Unable to create a required repository or query class " + ie);  
		  return result_concepts; 
		}
		
		catch(Exception e)
		{
		  
		  logger.error(this + " Unable to create a required repository or query class " + e);   
		  return result_concepts; 
		}
		
		
		
	}

	/** TODO-  not implemented, returns null
	 */	
	public Concept[] getConceptsMatchingRegexByThesaurus(String regex_, URI thes_uri) {
		return null;
	}
	
	/** TODO -  not implemented, returns null
	 */	
	public Concept[] getConceptsMatchingRegex(String regex_) {
		return null;
	}
	
	/** Get an array of the Relations ( {@link Relation} ) supported by this service
	 */	
	public Relation[] getSupportedSemanticRelations() {
					
					
		logger.debug(this + "Calling the getSupportedSemanticRelations method.");               
		ArrayList result_relations = new ArrayList();
		try {
				// TODO: For now we HARDCODE the relations to be added to the resulting array
				// because we know which relations our repository supports
				// However, longer term, we could implement this method by way of
				// a query that queries the repo schema to see which sub-properties of
				// type  skos:semanticRelation exist. Then we will be able to return this 
				// information as an array of relation 'objects'.
				ArrayList rel_array = new ArrayList();
				rel_array.add("http://www.w3.org/2004/02/skos/core#broader");
				rel_array.add("http://www.w3.org/2004/02/skos/core#narrower");
				rel_array.add("http://www.w3.org/2004/02/skos/core#related");
				rel_array.add("http://www.w3.org/2004/02/skos/core#broaderInstantive");
				rel_array.add("http://www.w3.org/2004/02/skos/core#narrowerInstantive");
				rel_array.add("http://www.w3.org/2004/02/skos/core#broaderGeneric");
				rel_array.add("http://www.w3.org/2004/02/skos/core#narrowerGeneric");
				rel_array.add("http://www.w3.org/2004/02/skos/core#broaderPartitive");
				rel_array.add("http://www.w3.org/2004/02/skos/core#narrowerPartitive");
				rel_array.add("http://www.w3.org/2004/02/skos/core#relatedHasPart");
				rel_array.add("http://www.w3.org/2004/02/skos/core#relatedPartOf");
				for (int n = 0; n < rel_array.size(); n++) {
				  
					URI tmp_uri = new URI();
					Relation tmp_reln = new Relation();
					tmp_uri.setUri(rel_array.get(n).toString());
					tmp_reln.setUri(tmp_uri);                       
					result_relations.add(tmp_reln);                         
				}
						
				return (Relation []) result_relations.toArray(new Relation[result_relations.size()]);
				
		} 

									
		catch(Exception e)
		{
		
		  logger.error(this + " Error returning relation array " + e);  
		  return null; 
		}
		
	}
  
	/** Get an array of the Relations ( {@link Relation} ) supported by this service
	 *  for a particular thesaurus.
	 * @param  thes_uri  absolute URI for the thesaurus as known to the service
	 */	
	public Relation[] getSupportedSemanticRelationsByThesaurus(URI thes_uri) {
		
		logger.debug(this + "Calling the getSupportedSemanticRelationsByThesaurus method.");    
		ArrayList result_relations = new ArrayList();
		   try {
					  // TODO: For now we HARDCODE the relations to be added to the resulting array
					  // because we know which relations our repository supports
					  // However, longer term, we could implement this method by way of
					  // a query that queries the repo schema to see which sub-properties of
					  // type  skos:semanticRelation exist. Then we will be able to return this 
					  // information as an array of relation 'objects'.
					  ArrayList rel_array = new ArrayList();
					  rel_array.add("http://www.w3.org/2004/02/skos/core#broader");
					  rel_array.add("http://www.w3.org/2004/02/skos/core#narrower");
					  rel_array.add("http://www.w3.org/2004/02/skos/core#related");
					  rel_array.add("http://www.w3.org/2004/02/skos/core#broaderInstantive");
					  rel_array.add("http://www.w3.org/2004/02/skos/core#narrowerInstantive");
					  rel_array.add("http://www.w3.org/2004/02/skos/core#broaderGeneric");
					  rel_array.add("http://www.w3.org/2004/02/skos/core#narrowerGeneric");
					  rel_array.add("http://www.w3.org/2004/02/skos/core#broaderPartitive");
					  rel_array.add("http://www.w3.org/2004/02/skos/core#narrowerPartitive");
					  rel_array.add("http://www.w3.org/2004/02/skos/core#relatedHasPart");
					  rel_array.add("http://www.w3.org/2004/02/skos/core#relatedPartOf");
					  for (int n = 0; n < rel_array.size(); n++) {
							  URI tmp_uri = new URI();
							  Relation tmp_reln = new Relation();
							  tmp_uri.setUri(rel_array.get(n).toString());
							  tmp_reln.setUri(tmp_uri);                     
							  result_relations.add(tmp_reln);                               
					  }
						
					  return (Relation []) result_relations.toArray(new Relation[result_relations.size()]);
				
		   } 

		   catch(Exception e)
		   {
		     logger.error(this + " Error returning relation array " + e);       
		     return null; 
		   }
										
	}


	/** Get an array of Concepts ( {@link Concept} ) directly related to the given concept
	 *   by the given relation ({@link Relation})
	 * @param concept starting concept
	 * @param relation skos relation to be applied to the starting concept in order to derive related concepts 
	 */	
	public Concept[] getConceptRelatives(Concept concept, Relation relation) {
	  
	  
	 logger.debug(this + "Calling the getConceptRelatives method.");           
	 System.out.println(this + "Calling the getConceptRelatives method.");
	 Concept[] result_concepts = null;
	   
	 try {
						System.out.println(this + "Gonna try create query " + Class.forName(queryClassName).toString() + " object.");
						// first create a query object and parse the query
						// identify which type of query class to load 
						// currently hardcoded to instantiate an RQLQuery object
						Class query_ = Class.forName(queryClassName);
						AbstractQuery query = (AbstractQuery) query_.newInstance();
						query.parseQuery(concept.getUri(), relation);
						//   identify which type of repository ("repo") class to load
						Class repo_ = Class.forName(repoClassName);
						AbstractRepo repo = (AbstractRepo) repo_.newInstance();
						 repo.configure(mode);
						   
						// Now let the repo object do the work: it will take care of issuing the query 
						// against the appropriate repository, and parsing the results from the repository
						// into an array of concept objects.         
						result_concepts = repo.doSearch_for_concepts(query);
						return result_concepts;
				
	 } 

	 catch(ClassNotFoundException cnfe)
	 {
	   logger.error(this + " Unable to create a required repository or query class " + cnfe);        
	   return result_concepts; 
	 }
		
	 catch(IllegalAccessException iae)
	 {
	   logger.error(this + " Unable to create a required repository or query class " + iae); 
	   return result_concepts; 
	 }
	 catch(InstantiationException ie)
	 {
	   logger.error(this + " Unable to create a required repository or query class " + ie);  
	   return result_concepts; 
	 }
		
	 catch(Exception e)
	 {
		  
	   logger.error(this + " Unable to create a required repository or query class " + e);   
	   return result_concepts; 
	 }
	
	}

	/** Get an array of Concepts ( {@link Concept} ) directly related to the given concept
	 *   via any of the skos relations possible 
	 * @param conc_ starting concept
	 */	
	public Concept[] getAllConceptRelatives(Concept conc_){   
	
		logger.debug(this + "Calling the getAllConceptRelatives method.");           
		Concept[] result_concepts = null;
	   
		try {
						   // first create a query object and parse the query
						   // identify which type of query class to load 
						   // currently hardcoded to instantiate an RQLQuery object
						   Class query_ = Class.forName(queryClassName);
						   AbstractQuery query = (AbstractQuery) query_.newInstance();
						   query.parseQuery(conc_.getUri(), "all");
						   //   identify which type of repository ("repo") class to load
						   Class repo_ = Class.forName(repoClassName);
						   AbstractRepo repo = (AbstractRepo) repo_.newInstance();
							repo.configure(mode);
						   
						   // Now let the repo object do the work: it will take care of issuing the query 
						   // against the appropriate repository, and parsing the results from the repository
						   // into an array of concept objects.         
						   result_concepts = repo.doSearch_for_concepts(query);
						   return result_concepts;
				
		} 

		catch(ClassNotFoundException cnfe)
		{
		  logger.error(this + " Unable to create a required repository or query class " + cnfe);        
		  return result_concepts; 
		}
		
		catch(IllegalAccessException iae)
		{
		  logger.error(this + " Unable to create a required repository or query class " + iae); 
		  return result_concepts; 
		}
		catch(InstantiationException ie)
		{
		  logger.error(this + " Unable to create a required repository or query class " + ie);  
		  return result_concepts; 
		}
		
		catch(Exception e)
		{
		  
		  logger.error(this + " Unable to create a required repository or query class " + e);   
		  return result_concepts; 
		}
		
	}

	/** Get an array of Concepts ( {@link Concept} ) directly related to the given concept
	 *   by any of the skos relations, for a particular thesaurus
	 * @param conc_ starting concept
	 * @param  thes_uri  absolute URI for the thesaurus as known to the service
	 */	
	public Concept[] getAllConceptRelativesByThesaurus(Concept conc_, URI thes_uri){   
	
		logger.debug(this + "Calling the getAllConceptRelativesByThesaurus method.");           
		Concept[] result_concepts = null;
	   
		//return result_concepts;
		try {
						   // first create a query object and parse the query
			
						   // identify which type of query class to load 
						   // currently hardcoded to instantiate an RQLQuery object
						   Class query_ = Class.forName(queryClassName);
						   AbstractQuery query = (AbstractQuery) query_.newInstance();
						   query.parseQuery(conc_.getUri(), "all", thes_uri);
						   // System.out.println(" got query " + query.getQuery());
						   //   identify which type of repository ("repo") class to load
						   Class repo_ = Class.forName(repoClassName);
						   AbstractRepo repo = (AbstractRepo) repo_.newInstance();
							repo.configure(mode);
						   
						   // Now let the repo object do the work: it will take care of issuing the query 
						   // against the appropriate repository, and parsing the results from the repository
						   // into an array of concept objects.         
						   result_concepts = repo.doSearch_for_concepts(query);
						   return result_concepts;
				
		} 

		catch(ClassNotFoundException cnfe)
		{
		  logger.error(this + " Unable to create a required repository or query class " + cnfe);        
		  return result_concepts; 
		}
		
		catch(IllegalAccessException iae)
		{
		  logger.error(this + " Unable to create a required repository or query class " + iae); 
		  return result_concepts; 
		}
		catch(InstantiationException ie)
		{
		  logger.error(this + " Unable to create a required repository or query class " + ie);  
		  return result_concepts; 
		}
		
		catch(Exception e)
		{
		  
		  logger.error(this + " Unable to create a required repository or query class " + e);   
		  return result_concepts; 
		}
		
	}


	/** Get an array of Concepts ( {@link Concept} ) that are typed as top concepts
	 * and are broader than the given Concept 
	 * @param  uri  absolute URI for the given Concept
	 */	
	public Concept[] getTopmostConcepts(URI uri_) {
		logger.debug(this + "Calling the getTopmostConcepts method.");  
		Concept[] result_concepts = null;
		
		try {
			   Class query_ = Class.forName(queryClassName);
			   AbstractQuery query = (AbstractQuery) query_.newInstance();
			   query.parseGetTopConceptsQuery(uri_);
			   
			   Class repo_ = Class.forName(repoClassName);
			   AbstractRepo repo = (AbstractRepo) repo_.newInstance();
				repo.configure(mode);
			   
			   result_concepts = repo.doSearch_for_concepts(query);
			   
			   return result_concepts;
		   } 

		catch(ClassNotFoundException cnfe)
		{
		  logger.error(this + " Unable to create a required repository or query class " + cnfe);        
		  return result_concepts; 
		}
		
		catch(IllegalAccessException iae)
		{
		  logger.error(this + " Unable to create a required repository or query class " + iae); 
		  return result_concepts; 
		}
		catch(InstantiationException ie)
		{
		  logger.error(this + " Unable to create a required repository or query class " + ie);  
		  return result_concepts; 
		}
		catch(Exception e)
		{
		  logger.error(this + " Unable to create a required repository or query class " + e);   
		  return result_concepts; 
		}
						
	}
   
	/** Get an array of Concepts ( {@link Concept} ) that are typed as top concepts
	 * and are broader than the given Concept, for a particular thesaurus 
	 * @param  uri  absolute URI for the given Concept
 	 * @param  thes_uri  absolute URI for the thesaurus as known to the service
	 */	 
   public Concept[] getTopConcepts(Concept conc_, URI thes_uri) {
				
				
		logger.debug(this + "Calling the getTopConcepts method.");      
		// TODO - see if this works - write a test call in standalone test impl
		Concept[] result_concepts = null;
	   
		//return result_concepts;
		try {
				// first create a query object and parse the query
			
				// identify which type of query class to load
				Class query_ = Class.forName(queryClassName);
				AbstractQuery query = (AbstractQuery) query_.newInstance();
				query.parseQuery(conc_.getUri(), thes_uri);
				
				//      identify which type of repository ("repo") class to load
				Class repo_ = Class.forName(repoClassName);
				AbstractRepo repo = (AbstractRepo) repo_.newInstance();
				repo.configure(mode);
				
				// Now let the repo object do the work: it will take care of issuing the query 
				//against the appropriate repository, and parsing the results from the repository
				// into an array of concept objects.            
				result_concepts = repo.doSearch_for_concepts(query);
				return result_concepts;
				
		} 

		catch(ClassNotFoundException cnfe)
		{
		  logger.error(this + " Unable to create a required repository or query class " + cnfe);        
		  return result_concepts; 
		}
		
		catch(IllegalAccessException iae)
		{
		  logger.error(this + " Unable to create a required repository or query class " + iae); 
		  return result_concepts; 
		}
		catch(InstantiationException ie)
		{
		  logger.error(this + " Unable to create a required repository or query class " + ie);  
		  return result_concepts; 
		}
		
		catch(Exception e)
		{
		  logger.error(this + " Unable to create a required repository or query class " + e);   
		  return result_concepts; 
		}
				
   }

 /**
  * Not implemented. Likely to be deprecated
  * @param in0
  * @param in1
  * @return
  */
   public Concept getConceptByInternalID(String in0, URI in1)
   {
		//      TODO: Not implemented (obsolete?)
		return null;
   }

/** TODO: Not implemented. 
 * 
 */
   public ConceptRelatives[] getAllConceptsByPath(Concept conc_, Relation reln, int int_)
   {
		//              TODO: Not implemented
		return null;
   }

   /** Get an array of Concepts ( {@link Concept} ) directly related to the given concept
	*   via the given skos relation, for a particular thesaurus
	* @param conc_ starting concept
	* @param  thes_uri  absolute URI for the thesaurus as known to the service
	 * @param relation skos relation to be applied to the starting concept in order to derive related concepts 
	*/						 
   public Concept[] getConceptRelativesByThesaurus(Concept conc_, Relation rln, URI uri_)
   {
			
			
		logger.debug(this + "Calling the getConceptRelativesByThesaurus method.");              
		Concept[] result_concepts = null;
	  try {
			// first create a query object and parse the query
			// identify which type of query class to load
			Class query_ = Class.forName(queryClassName);
			AbstractQuery query = (AbstractQuery) query_.newInstance();
			query.parseQuery(conc_.getUri(), rln, uri_);
			
			//      identify which type of repository ("repo") class to load
			Class repo_ = Class.forName(repoClassName);
			AbstractRepo repo = (AbstractRepo) repo_.newInstance();
			repo.configure(mode);
			
			// Now let the repo object do the work: it will take care of issuing the query 
			//against the appropriate repository, and parsing the results from the repository
			// into an array of concept objects.            
			result_concepts = repo.doSearch_for_concepts(query);
			return result_concepts;
			
		} 

		catch(ClassNotFoundException cnfe)
		{
		  logger.error(this + " Unable to create a required repository or query class " + cnfe);        
		  return result_concepts; 
		}
		
		catch(IllegalAccessException iae)
		{
		  logger.error(this + " Unable to create a required repository or query class " + iae); 
		  return result_concepts; 
		}
		catch(InstantiationException ie)
		{
		  logger.error(this + " Unable to create a required repository or query class " + ie);  
		  return result_concepts; 
		}
		
		catch(Exception e)
		{
		  
		  logger.error(this + " Unable to create a required repository or query class " + e);   
		  return result_concepts; 
		}
		
	}
	
  // TODO
	public ConceptRelatives[] getConceptRelativesByPath(Concept conc_, Relation rln, URI uri_, int int_) {
		
		System.out.println("About to run the recursion method with level " + int_ + " and relation " + rln.getLabel() + " and concept with uri" + conc_.getUri().getUri());
		// TODO - change this recursion method to include uri of thesaurus
		
		// Initialise concept relatives results object  (it will have reults appended to it via the Recursion method
		ConceptRelativesResults results = new ConceptRelativesResults(int_);
		// TODO - edit this - the concept may not have a uri - might be identifiable via keyword instead?
		getConceptRelativesRecursion(conc_.getUri(),rln, int_, results); 
		return results.fetchResults();
	}                                       
	

	// TODO - change this to accept a concept not a uri? 
	// TODO - change this to accept the thesaurus uri as well (& then do method - getConceptRelatives by thes)
	// Note that we can also call getAllConceptRelatives in order to implement the getAllConceptRelativesByPath
	private void getConceptRelativesRecursion(URI conc_uri, Relation reln, int level, ConceptRelativesResults results) {
		Concept[] curr_concepts;
		Concept tmp_concept = new Concept();
		ConceptRelatives concept_relatives = new ConceptRelatives();
		//	int initial_level = level;
		//TODO - try catch blocks needed
		tmp_concept.setUri(conc_uri);
		
		if (level > 0) {
			System.out.println("level is " + level); 
			curr_concepts = getConceptRelatives(tmp_concept,reln);
			
	
			System.out.println("Got " + curr_concepts.length +  "  concepts at  level " + level);
			// debug *******************
			
			for (int i = 0; i < (curr_concepts.length); i++) {
						System.out.println("Concept uri:  " + curr_concepts[i].getUri().getUri());
			} 
			System.out.println("Going to load up ConceptRelatives at this point. ");
			// Append concept relatives object with the concept array and level
			// and have the results object "add" it to an arraylist
				if (curr_concepts.length > 0) {
					concept_relatives.setDistance(level);
					concept_relatives.setConcepts(curr_concepts);
					concept_relatives.setRelation(reln);
					results.appendResults(concept_relatives);
				System.out.println("Now going to enter for loop to call this method recursively ");
					for (int n = 0; n < (curr_concepts.length); n++) {
							level--;	
							getConceptRelativesRecursion(curr_concepts[n].getUri(),reln,level, results);
												
					}
			}
	
		}
		// This method returns nothing - it instead appends results as they come in to a results object
		// the results object can compose an array of concept relatives - & gets initiated with the original level
		// so it can work in reverse to deduce level of resulting concept relatives
	
	}
	
	
}
