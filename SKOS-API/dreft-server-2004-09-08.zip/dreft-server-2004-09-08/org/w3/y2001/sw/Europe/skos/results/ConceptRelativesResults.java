package org.w3.y2001.sw.Europe.skos.results;

import org.apache.log4j.Logger;
import java.util.ArrayList;

import org.w3.y2001.sw.Europe.skos.ConceptRelatives;


/**
 *
 * @author Nikki Rogers
  */
public class ConceptRelativesResults  {

	/*
	 * @return 
	 * @exception 
	 * 
	  **/
	
	// The results object will hold an ArrayList resultset - ConceptRelative objects get added to this
		// via the recursive method below (with their level reset before each is added). Then, when finished, this method will call a
		// "fetch results" method on the results object. The fetch results method will cast the ArrayList
		// to a ConceptRelatives[] object & returned. This method then returns that object.
	
	private int path_level = 0;
	// ConceptRelative objects are added to this ArrayList resultset as the recursive method in DemoService
	// builds them. The fetch results method then casts this ArrayList to a ConceptRelative[] object to be returned 
	// to the getConceptRelativesbyPath method in DemoService.
	private ArrayList resultset = new ArrayList();
	
	static Logger logger = Logger.getLogger(ConceptRelativesResults.class.getName());
	
	public ConceptRelativesResults(int initial_level){
		logger.debug(this + "Constructing a ConceptRelativesResults object ...");
		System.out.println("Constructing a ConceptRelativesResults object ..");
		if (initial_level > 0){
		
				path_level = initial_level;			
				logger.debug(this + "Setting initial path level to: " + path_level);
				System.out.println(this + "Setting initial path level to: " + path_level);
	
		}				
		else 	logger.error(this + "Initial path level is not greater than zero.");
	}
	
	public void appendResults(ConceptRelatives relatives) {
			// reset the distance for this array of concept relatives (because the recursive method assigns
			// the distance in reverse order
			//  original_level + 1 - existing_level
			logger.debug(this + "Appending some ConceptRelative results at level: " + (path_level + 1 - relatives.getDistance()));
			System.out.println(this + "Appending some ConceptRelative results at level: " + (path_level + 1 - relatives.getDistance()));
			relatives.setDistance(path_level + 1 - (relatives.getDistance()));
			resultset.add(relatives);
	}	
	
	public ConceptRelatives[] fetchResults() {
		
			//	cast from an ArrayList to a ConceptRelatives[]
			logger.debug(this + "Returning ConceptRelative final array of size: " + resultset.size());
			System.out.println(this + "Returning ConceptRelative final array of size: " + resultset.size());
			return (ConceptRelatives[]) resultset.toArray(new ConceptRelatives [resultset.size()]);
	}	
	


}
	