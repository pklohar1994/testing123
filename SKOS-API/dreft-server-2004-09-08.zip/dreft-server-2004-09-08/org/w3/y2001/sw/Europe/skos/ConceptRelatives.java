/**
 * ConceptRelatives.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package org.w3.y2001.sw.Europe.skos;

public class ConceptRelatives  implements java.io.Serializable {
    private int distance;
    private org.w3.y2001.sw.Europe.skos.Concept[] concepts;
    private org.w3.y2001.sw.Europe.skos.Relation relation;

    public ConceptRelatives() {
    }

    public int getDistance() {
        return distance;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public org.w3.y2001.sw.Europe.skos.Concept[] getConcepts() {
        return concepts;
    }

    public void setConcepts(org.w3.y2001.sw.Europe.skos.Concept[] concepts) {
        this.concepts = concepts;
    }

    public org.w3.y2001.sw.Europe.skos.Concept getConcepts(int i) {
        return concepts[i];
    }

    public void setConcepts(int i, org.w3.y2001.sw.Europe.skos.Concept value) {
        this.concepts[i] = value;
    }

    public org.w3.y2001.sw.Europe.skos.Relation getRelation() {
        return relation;
    }

    public void setRelation(org.w3.y2001.sw.Europe.skos.Relation relation) {
        this.relation = relation;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConceptRelatives)) return false;
        ConceptRelatives other = (ConceptRelatives) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.distance == other.getDistance() &&
            ((this.concepts==null && other.getConcepts()==null) || 
             (this.concepts!=null &&
              java.util.Arrays.equals(this.concepts, other.getConcepts()))) &&
            ((this.relation==null && other.getRelation()==null) || 
             (this.relation!=null &&
              this.relation.equals(other.getRelation())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getDistance();
        if (getConcepts() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getConcepts());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getConcepts(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRelation() != null) {
            _hashCode += getRelation().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConceptRelatives.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "ConceptRelatives"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("distance");
        elemField.setXmlName(new javax.xml.namespace.QName("", "distance"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("concepts");
        elemField.setXmlName(new javax.xml.namespace.QName("", "concepts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Concept"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("relation");
        elemField.setXmlName(new javax.xml.namespace.QName("", "relation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/sw/Europe/skos/namespace", "Relation"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
