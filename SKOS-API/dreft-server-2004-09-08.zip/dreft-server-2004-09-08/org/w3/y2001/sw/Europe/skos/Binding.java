/** SKOS Thesaurus API
 *
 * @author Dave Beckett, Nikki Rogers, Alistair Miles.
 * @version $Id: Binding.java,v 1.5 2004/04/29 10:39:00 cmdjb Exp $ .
 *
 */

package org.w3.y2001.sw.Europe.skos;

/**
 * A class for a query result binding from an RDF query service.
 * The literalValue, URIvalue and bnodeValue are alternatives.
 */

public class Binding {
  public String variable;

  public String literalValue;
  public String URIvalue;
  public String bnodeValue;
}
